"""
Workflow API Views — admin configuration + user-facing actions.
"""
from django.contrib.contenttypes.models import ContentType
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from workflow.engine import (
    get_pending_approvals, process_action, can_user_act,
    start_workflow, resubmit_workflow, get_effective_approvers_for_stage,
)
from workflow.models import (
    Workflow, WorkflowStage, StageApprover,
    ApproverDelegation, WorkflowInstance,
)
from workflow.serializers import (
    WorkflowSerializer, WorkflowStageSerializer, StageApproverSerializer,
    DelegationSerializer, WorkflowInstanceSerializer,
)


# ─────────────────────────────────────────────────────────────────────────────
# Admin Configuration Views
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowListView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        qs = Workflow.objects.select_related('content_type').all()
        search = request.query_params.get('search')
        if search:
            qs = qs.filter(name__icontains=search)
        return Response(WorkflowSerializer(qs, many=True).data)

    def post(self, request):
        serializer = WorkflowSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class WorkflowDetailView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request, pk):
        try:
            wf = Workflow.objects.get(pk=pk)
        except Workflow.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        return Response(WorkflowSerializer(wf).data)

    def patch(self, request, pk):
        try:
            wf = Workflow.objects.get(pk=pk)
        except Workflow.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        serializer = WorkflowSerializer(wf, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        try:
            wf = Workflow.objects.get(pk=pk)
        except Workflow.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        wf.delete()
        return Response({'message': 'Deleted'})


class StageListView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request, workflow_id):
        stages = WorkflowStage.objects.filter(workflow_id=workflow_id).prefetch_related('approvers')
        return Response(WorkflowStageSerializer(stages, many=True).data)

    def post(self, request, workflow_id):
        data = {**request.data, 'workflow': workflow_id}
        serializer = WorkflowStageSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class StageDetailView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def patch(self, request, pk):
        try:
            stage = WorkflowStage.objects.get(pk=pk)
        except WorkflowStage.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        serializer = WorkflowStageSerializer(stage, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        try:
            stage = WorkflowStage.objects.get(pk=pk)
        except WorkflowStage.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        stage.delete()
        return Response({'message': 'Deleted'})


class ApproverView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request, stage_id):
        data = {**request.data, 'stage': stage_id}
        serializer = StageApproverSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def delete(self, request, pk):
        try:
            sa = StageApprover.objects.get(pk=pk)
        except StageApprover.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        sa.delete()
        return Response({'message': 'Deleted'})


class DelegationListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Admins see all, regular users see their own
        if request.user.is_staff:
            qs = ApproverDelegation.objects.all()
        else:
            qs = ApproverDelegation.objects.filter(delegator=request.user)
        return Response(DelegationSerializer(qs, many=True).data)

    def post(self, request):
        data = request.data.copy()
        if not request.user.is_staff:
            data['delegator'] = request.user.id
        serializer = DelegationSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class DelegationDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, pk):
        try:
            d = ApproverDelegation.objects.get(pk=pk)
        except ApproverDelegation.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        if not request.user.is_staff and d.delegator != request.user:
            return Response({'detail': 'Forbidden'}, status=403)
        serializer = DelegationSerializer(d, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        try:
            d = ApproverDelegation.objects.get(pk=pk)
        except ApproverDelegation.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        if not request.user.is_staff and d.delegator != request.user:
            return Response({'detail': 'Forbidden'}, status=403)
        d.delete()
        return Response({'message': 'Deleted'})


# ─────────────────────────────────────────────────────────────────────────────
# User-Facing Views
# ─────────────────────────────────────────────────────────────────────────────

class PendingApprovalsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        instances = get_pending_approvals(request.user)
        return Response(WorkflowInstanceSerializer(instances, many=True).data)


class WorkflowInstanceDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            instance = WorkflowInstance.objects.get(pk=pk)
        except WorkflowInstance.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)
        data = WorkflowInstanceSerializer(instance).data
        data['can_act'] = can_user_act(instance, request.user)
        if instance.current_stage:
            approvers = get_effective_approvers_for_stage(instance.current_stage)
            data['current_approvers'] = [
                {'id': u.id, 'name': u.get_full_name() or u.username}
                for u in approvers
            ]
        return Response(data)


class WorkflowActionView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            instance = WorkflowInstance.objects.get(pk=pk)
        except WorkflowInstance.DoesNotExist:
            return Response({'detail': 'Not found'}, status=404)

        action = request.data.get('action')
        comment = request.data.get('comment', '')

        if action == 'resubmit':
            new_instance, msg = resubmit_workflow(instance, request.user)
            if new_instance:
                return Response(WorkflowInstanceSerializer(new_instance).data)
            return Response({'detail': msg}, status=400)

        if action not in ('approve', 'reject', 'return'):
            return Response({'detail': 'Invalid action'}, status=400)

        success, msg = process_action(instance, request.user, action, comment)
        if success:
            instance.refresh_from_db()
            return Response({
                'message': msg,
                'instance': WorkflowInstanceSerializer(instance).data,
            })
        return Response({'detail': msg}, status=400)


class RecordWorkflowView(APIView):
    """Get workflow status for a specific record."""
    permission_classes = [IsAuthenticated]

    def get(self, request, app_label, model_name, object_id):
        try:
            ct = ContentType.objects.get(app_label=app_label, model=model_name)
        except ContentType.DoesNotExist:
            return Response({'detail': 'Model not found'}, status=404)

        instances = WorkflowInstance.objects.filter(
            content_type=ct, object_id=object_id
        ).order_by('-attempt')[:5]

        return Response(WorkflowInstanceSerializer(instances, many=True).data)


class ManualStartView(APIView):
    """Manually start a workflow for a record (for manual trigger type)."""
    permission_classes = [IsAuthenticated]

    def post(self, request, app_label, model_name, object_id):
        try:
            ct = ContentType.objects.get(app_label=app_label, model=model_name)
        except ContentType.DoesNotExist:
            return Response({'detail': 'Model not found'}, status=404)

        model_class = ct.model_class()
        try:
            record = model_class.objects.get(pk=object_id)
        except model_class.DoesNotExist:
            return Response({'detail': 'Record not found'}, status=404)

        workflow = Workflow.objects.filter(
            content_type=ct, is_active=True, trigger_type='manual'
        ).first()
        if not workflow:
            return Response({'detail': 'No manual workflow configured for this model'}, status=404)

        instance = start_workflow(record, request.user, workflow=workflow)
        if instance:
            return Response(WorkflowInstanceSerializer(instance).data, status=201)
        return Response({'detail': 'Failed to start workflow'}, status=400)
