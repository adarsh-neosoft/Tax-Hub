from django.contrib.auth.models import User, Group
from django.contrib.contenttypes.models import ContentType
from django.db import models


class Workflow(models.Model):
    """A named approval workflow attached to a specific model."""

    TRIGGER_CHOICES = [
        ('auto_on_create', 'Auto on Create'),
        ('auto_on_update', 'Auto on Update'),
        ('manual', 'Manual (Submit button)'),
    ]

    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, related_name='workflows')
    is_active = models.BooleanField(default=True)
    trigger_type = models.CharField(max_length=20, choices=TRIGGER_CHOICES, default='manual')
    allow_resubmission = models.BooleanField(default=True, help_text="Whether rejected/returned instances can be resubmitted")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'workflow'
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.content_type})"


class WorkflowStage(models.Model):
    """A stage/step within a workflow."""

    STAGE_TYPE_CHOICES = [
        ('sequential', 'Sequential (one approver)'),
        ('parallel_all', 'Parallel - All must approve'),
        ('parallel_any', 'Parallel - Any one can approve'),
    ]

    RETURN_TO_CHOICES = [
        ('previous_stage', 'Return to previous stage'),
        ('initiator', 'Return to initiator (stage 1)'),
        ('specific_stage', 'Return to a specific stage'),
    ]

    workflow = models.ForeignKey(Workflow, on_delete=models.CASCADE, related_name='stages')
    order = models.PositiveIntegerField()
    name = models.CharField(max_length=255)
    stage_type = models.CharField(max_length=20, choices=STAGE_TYPE_CHOICES, default='sequential')
    allow_return = models.BooleanField(default=True, help_text="Whether approvers at this stage can return the request")
    return_to = models.CharField(max_length=20, choices=RETURN_TO_CHOICES, default='previous_stage')
    return_to_stage = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True, related_name='return_targets'
    )

    class Meta:
        db_table = 'workflow_stage'
        ordering = ['workflow', 'order']
        unique_together = ['workflow', 'order']

    def __str__(self):
        return f"{self.workflow.name} → Stage {self.order}: {self.name}"


class StageApprover(models.Model):
    """An approver (user or group) assigned to a workflow stage."""
    stage = models.ForeignKey(WorkflowStage, on_delete=models.CASCADE, related_name='approvers')
    approver_user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='stage_approvals')
    approver_group = models.ForeignKey(Group, on_delete=models.CASCADE, null=True, blank=True, related_name='stage_approvals')
    order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = 'workflow_stage_approver'
        ordering = ['stage', 'order']

    def __str__(self):
        approver = self.approver_user or self.approver_group
        return f"{self.stage} → {approver}"


class ApproverDelegation(models.Model):
    """Delegation of approval authority from one user to another."""
    delegator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='delegations_given')
    delegate = models.ForeignKey(User, on_delete=models.CASCADE, related_name='delegations_received')
    workflow = models.ForeignKey(Workflow, on_delete=models.CASCADE, null=True, blank=True,
                                related_name='delegations', help_text="Null = applies to all workflows")
    valid_from = models.DateTimeField()
    valid_until = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'workflow_delegation'
        ordering = ['-valid_from']

    def __str__(self):
        scope = self.workflow.name if self.workflow else "All workflows"
        return f"{self.delegator} → {self.delegate} ({scope})"


class WorkflowInstance(models.Model):
    """A running instance of a workflow attached to a specific record."""

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('returned', 'Returned'),
    ]

    workflow = models.ForeignKey(Workflow, on_delete=models.CASCADE, related_name='instances')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    current_stage = models.ForeignKey(WorkflowStage, on_delete=models.SET_NULL, null=True, blank=True)
    initiated_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='workflow_instances')
    initiated_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    attempt = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'workflow_instance'
        ordering = ['-initiated_at']

    def __str__(self):
        return f"{self.workflow.name} for {self.content_type.model}#{self.object_id} (attempt {self.attempt})"


class WorkflowAction(models.Model):
    """An action taken by an approver on a workflow instance."""

    ACTION_CHOICES = [
        ('approve', 'Approve'),
        ('reject', 'Reject'),
        ('return', 'Return'),
        ('resubmit', 'Resubmit'),
    ]

    instance = models.ForeignKey(WorkflowInstance, on_delete=models.CASCADE, related_name='actions')
    stage = models.ForeignKey(WorkflowStage, on_delete=models.CASCADE)
    actor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='workflow_actions')
    acted_on_behalf_of = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='delegated_workflow_actions',
        help_text="Set when a delegate acts on behalf of the original approver"
    )
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    comment = models.TextField(blank=True)
    acted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'workflow_action'
        ordering = ['acted_at']

    def __str__(self):
        return f"{self.actor} → {self.action} on {self.instance} (stage: {self.stage.name})"
