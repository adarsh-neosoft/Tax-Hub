from django.urls import path
from workflow import views

urlpatterns = [
    # Admin — Workflow configuration
    path('workflows/', views.WorkflowListView.as_view()),
    path('workflows/<int:pk>/', views.WorkflowDetailView.as_view()),
    path('workflows/<int:workflow_id>/stages/', views.StageListView.as_view()),
    path('stages/<int:pk>/', views.StageDetailView.as_view()),
    path('stages/<int:stage_id>/approvers/', views.ApproverView.as_view()),
    path('approvers/<int:pk>/', views.ApproverView.as_view()),

    # Delegations
    path('delegations/', views.DelegationListView.as_view()),
    path('delegations/<int:pk>/', views.DelegationDetailView.as_view()),

    # User-facing
    path('pending/', views.PendingApprovalsView.as_view()),
    path('instance/<int:pk>/', views.WorkflowInstanceDetailView.as_view()),
    path('instance/<int:pk>/action/', views.WorkflowActionView.as_view()),
    path('record/<str:app_label>/<str:model_name>/<int:object_id>/',
         views.RecordWorkflowView.as_view()),
    path('start/<str:app_label>/<str:model_name>/<int:object_id>/',
         views.ManualStartView.as_view()),
]
