from django.contrib.auth.models import User, Group
from django.contrib.contenttypes.models import ContentType
from rest_framework import serializers

from workflow.models import (
    Workflow, WorkflowStage, StageApprover,
    ApproverDelegation, WorkflowInstance, WorkflowAction,
)


class WorkflowSerializer(serializers.ModelSerializer):
    content_type_label = serializers.SerializerMethodField()
    stage_count = serializers.SerializerMethodField()

    class Meta:
        model = Workflow
        fields = ['id', 'name', 'description', 'content_type', 'content_type_label',
                  'is_active', 'trigger_type', 'allow_resubmission', 'stage_count',
                  'created_at', 'updated_at']

    def get_content_type_label(self, obj):
        return f"{obj.content_type.app_label} | {obj.content_type.model}"

    def get_stage_count(self, obj):
        return obj.stages.count()


class StageApproverSerializer(serializers.ModelSerializer):
    approver_name = serializers.SerializerMethodField()

    class Meta:
        model = StageApprover
        fields = ['id', 'stage', 'approver_user', 'approver_group', 'order', 'approver_name']

    def get_approver_name(self, obj):
        if obj.approver_user:
            return obj.approver_user.get_full_name() or obj.approver_user.username
        if obj.approver_group:
            return f"Group: {obj.approver_group.name}"
        return ""


class WorkflowStageSerializer(serializers.ModelSerializer):
    approvers = StageApproverSerializer(many=True, read_only=True)

    class Meta:
        model = WorkflowStage
        fields = ['id', 'workflow', 'order', 'name', 'stage_type',
                  'allow_return', 'return_to', 'return_to_stage', 'approvers']


class DelegationSerializer(serializers.ModelSerializer):
    delegator_name = serializers.SerializerMethodField()
    delegate_name = serializers.SerializerMethodField()
    workflow_name = serializers.SerializerMethodField()

    class Meta:
        model = ApproverDelegation
        fields = ['id', 'delegator', 'delegator_name', 'delegate', 'delegate_name',
                  'workflow', 'workflow_name', 'valid_from', 'valid_until', 'is_active']

    def get_delegator_name(self, obj):
        return obj.delegator.get_full_name() or obj.delegator.username

    def get_delegate_name(self, obj):
        return obj.delegate.get_full_name() or obj.delegate.username

    def get_workflow_name(self, obj):
        return obj.workflow.name if obj.workflow else "All workflows"


class WorkflowActionSerializer(serializers.ModelSerializer):
    actor_name = serializers.SerializerMethodField()
    on_behalf_of_name = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowAction
        fields = ['id', 'instance', 'stage', 'actor', 'actor_name',
                  'acted_on_behalf_of', 'on_behalf_of_name', 'action', 'comment', 'acted_at']

    def get_actor_name(self, obj):
        return obj.actor.get_full_name() or obj.actor.username

    def get_on_behalf_of_name(self, obj):
        if obj.acted_on_behalf_of:
            return obj.acted_on_behalf_of.get_full_name() or obj.acted_on_behalf_of.username
        return None


class WorkflowInstanceSerializer(serializers.ModelSerializer):
    workflow_name = serializers.CharField(source='workflow.name', read_only=True)
    allow_resubmission = serializers.BooleanField(source='workflow.allow_resubmission', read_only=True)
    allow_return = serializers.SerializerMethodField()
    current_stage_name = serializers.SerializerMethodField()
    model_name = serializers.SerializerMethodField()
    actions = WorkflowActionSerializer(many=True, read_only=True)
    initiated_by_name = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowInstance
        fields = ['id', 'workflow', 'workflow_name', 'allow_resubmission', 'allow_return',
                  'content_type', 'object_id',
                  'model_name', 'status', 'current_stage', 'current_stage_name',
                  'initiated_by', 'initiated_by_name', 'initiated_at',
                  'completed_at', 'attempt', 'actions']

    def get_allow_return(self, obj):
        return obj.current_stage.allow_return if obj.current_stage else False

    def get_current_stage_name(self, obj):
        return obj.current_stage.name if obj.current_stage else None

    def get_model_name(self, obj):
        return f"{obj.content_type.app_label}.{obj.content_type.model}"

    def get_initiated_by_name(self, obj):
        return obj.initiated_by.get_full_name() or obj.initiated_by.username
