"""
Management command to set up a complex test workflow for PurchaseOrder.

Workflow: "Purchase Order Approval"
  Stage 1: Manager Approval (Sequential) — single user approves
  Stage 2: Finance & Compliance (Parallel All) — both must approve
  Stage 3: Director Sign-off (Parallel Any) — any one director suffices

Also creates test users and groups to demonstrate the workflow.
"""
from django.contrib.auth.models import User, Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand

from workflow.models import Workflow, WorkflowStage, StageApprover


class Command(BaseCommand):
    help = "Set up a complex test workflow for PurchaseOrder model"

    def handle(self, *args, **options):
        self.stdout.write("Setting up test workflow...\n")

        # 1. Create test users
        users = {}
        user_data = [
            ('manager1', 'Project', 'Manager'),
            ('finance_head', 'Finance', 'Head'),
            ('compliance_head', 'Compliance', 'Head'),
            ('director1', 'Director', 'One'),
            ('director2', 'Director', 'Two'),
            ('requester1', 'John', 'Requester'),
        ]
        for username, first, last in user_data:
            user, created = User.objects.get_or_create(
                username=username,
                defaults={'first_name': first, 'last_name': last, 'is_active': True}
            )
            if created:
                user.set_password('test123')
                user.save()
                self.stdout.write(f"  Created user: {username}")
            users[username] = user

        # 2. Create groups
        finance_group, _ = Group.objects.get_or_create(name='Finance Team')
        directors_group, _ = Group.objects.get_or_create(name='Directors')

        # Add users to groups
        users['finance_head'].groups.add(finance_group)
        users['director1'].groups.add(directors_group)
        users['director2'].groups.add(directors_group)

        # 3. Grant permissions to requester
        ct = ContentType.objects.get(app_label='masters', model='purchaseorder')
        for codename in ['add_purchaseorder', 'change_purchaseorder',
                         'view_purchaseorder', 'delete_purchaseorder']:
            perm = Permission.objects.get(codename=codename, content_type=ct)
            users['requester1'].user_permissions.add(perm)
            users['manager1'].user_permissions.add(perm)

        # 4. Create the workflow
        workflow, created = Workflow.objects.get_or_create(
            name='Purchase Order Approval',
            content_type=ct,
            defaults={
                'description': 'Complex 3-stage approval: Manager → Finance+Compliance → Director',
                'is_active': True,
                'trigger_type': 'manual',  # User clicks "Submit for Approval"
            }
        )
        if not created:
            self.stdout.write("  Workflow already exists, skipping stage creation.")
            return

        self.stdout.write(f"  Created workflow: {workflow.name}")

        # 5. Create stages

        # Stage 1: Sequential — Manager
        stage1 = WorkflowStage.objects.create(
            workflow=workflow,
            order=1,
            name='Manager Approval',
            stage_type='sequential',
            return_to='initiator',
        )
        StageApprover.objects.create(stage=stage1, approver_user=users['manager1'], order=1)
        self.stdout.write(f"  Stage 1: {stage1.name} (approver: manager1)")

        # Stage 2: Parallel All — Finance Head AND Compliance Head must both approve
        stage2 = WorkflowStage.objects.create(
            workflow=workflow,
            order=2,
            name='Finance & Compliance Review',
            stage_type='parallel_all',
            return_to='previous_stage',
        )
        StageApprover.objects.create(stage=stage2, approver_user=users['finance_head'], order=1)
        StageApprover.objects.create(stage=stage2, approver_user=users['compliance_head'], order=2)
        self.stdout.write(f"  Stage 2: {stage2.name} (approvers: finance_head, compliance_head)")

        # Stage 3: Parallel Any — Any one director can approve
        stage3 = WorkflowStage.objects.create(
            workflow=workflow,
            order=3,
            name='Director Sign-off',
            stage_type='parallel_any',
            return_to='previous_stage',
        )
        StageApprover.objects.create(stage=stage3, approver_group=directors_group, order=1)
        self.stdout.write(f"  Stage 3: {stage3.name} (approver group: Directors)")

        self.stdout.write(self.style.SUCCESS(
            "\n✓ Workflow setup complete!\n"
            "\nTest scenario:\n"
            "  1. Login as 'requester1' (password: test123)\n"
            "  2. Create a Purchase Order\n"
            "  3. Click 'Submit for Approval' on the edit form\n"
            "  4. Login as 'manager1' → Approve at Stage 1\n"
            "  5. Login as 'finance_head' → Approve at Stage 2\n"
            "  6. Login as 'compliance_head' → Approve at Stage 2 (both needed)\n"
            "  7. Login as 'director1' OR 'director2' → Approve at Stage 3 (any one)\n"
            "  8. PO becomes is_approved=True\n"
        ))
