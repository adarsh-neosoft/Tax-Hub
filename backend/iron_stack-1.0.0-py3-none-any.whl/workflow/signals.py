"""
Signals to auto-trigger workflows on model save.
"""
from django.contrib.contenttypes.models import ContentType
from django.db.models.signals import post_save
from django.dispatch import receiver

from workflow.models import Workflow


@receiver(post_save)
def auto_trigger_workflow(sender, instance, created, **kwargs):
    """
    Auto-start a workflow when a record is created or updated,
    if there's an active workflow configured for that model.
    """
    # Skip workflow models themselves to avoid recursion
    if sender._meta.app_label == 'workflow':
        return

    # Skip models without the workflow_config attribute
    if not hasattr(sender, 'workflow_config'):
        return

    config = sender.workflow_config
    if not config.get('enabled'):
        return

    ct = ContentType.objects.get_for_model(sender)

    if created:
        workflow = Workflow.objects.filter(
            content_type=ct, is_active=True, trigger_type='auto_on_create'
        ).first()
    else:
        workflow = Workflow.objects.filter(
            content_type=ct, is_active=True, trigger_type='auto_on_update'
        ).first()

    if workflow:
        from workflow.engine import start_workflow
        # Use the instance's created_by if available, fallback to None
        user = getattr(instance, 'created_by', None)
        if user:
            start_workflow(instance, user, workflow=workflow)
