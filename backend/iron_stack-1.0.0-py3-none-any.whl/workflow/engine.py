"""
Workflow Engine — core business logic for starting, advancing, and
completing approval workflows.
"""
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone

from workflow.models import (
    Workflow, WorkflowStage, StageApprover,
    ApproverDelegation, WorkflowInstance, WorkflowAction,
)


def get_workflow_for_model(model_class, trigger_type=None):
    """Find the active workflow for a given model and optional trigger type."""
    ct = ContentType.objects.get_for_model(model_class)
    qs = Workflow.objects.filter(content_type=ct, is_active=True)
    if trigger_type:
        qs = qs.filter(trigger_type=trigger_type)
    return qs.first()


def start_workflow(record, user, workflow=None):
    """
    Start a workflow instance for the given record.
    Returns the WorkflowInstance or None if no workflow applies.
    """
    if workflow is None:
        ct = ContentType.objects.get_for_model(record)
        workflow = Workflow.objects.filter(content_type=ct, is_active=True).first()

    if not workflow:
        return None

    first_stage = workflow.stages.order_by('order').first()
    if not first_stage:
        return None

    ct = ContentType.objects.get_for_model(record)

    # Check for existing pending instance
    existing = WorkflowInstance.objects.filter(
        workflow=workflow, content_type=ct, object_id=record.pk, status='pending'
    ).first()
    if existing:
        return existing

    # Determine attempt number
    last_attempt = WorkflowInstance.objects.filter(
        workflow=workflow, content_type=ct, object_id=record.pk
    ).order_by('-attempt').first()
    attempt = (last_attempt.attempt + 1) if last_attempt else 1

    instance = WorkflowInstance.objects.create(
        workflow=workflow,
        content_type=ct,
        object_id=record.pk,
        status='pending',
        current_stage=first_stage,
        initiated_by=user,
        attempt=attempt,
    )
    return instance


def get_effective_approvers(stage, workflow=None):
    """
    Get all users who can approve a stage, including delegates.
    Returns a set of User objects.
    """
    now = timezone.now()
    approvers = set()

    for sa in stage.approvers.all():
        if sa.approver_user:
            approvers.add(sa.approver_user)
        if sa.approver_group:
            approvers.update(sa.approver_group.user_set.all())

    # Add delegates
    delegates = set()
    for user in approvers:
        delegations = ApproverDelegation.objects.filter(
            delegator=user,
            is_active=True,
            valid_from__lte=now,
            valid_until__gte=now,
        )
        if workflow:
            delegations = delegations.filter(
                models_Q_workflow_null_or_match(workflow)
            )
        for d in delegations:
            delegates.add(d.delegate)

    approvers.update(delegates)
    return approvers


def models_Q_workflow_null_or_match(workflow):
    """Helper: filter delegations where workflow is null OR matches."""
    from django.db.models import Q
    return Q(workflow__isnull=True) | Q(workflow=workflow)


def get_effective_approvers_for_stage(stage):
    """Public API: get approvers including delegates for a stage."""
    now = timezone.now()
    approvers = set()

    for sa in stage.approvers.select_related('approver_user', 'approver_group').all():
        if sa.approver_user:
            approvers.add(sa.approver_user)
        if sa.approver_group:
            approvers.update(sa.approver_group.user_set.all())

    # Add active delegates
    original_approvers = list(approvers)
    for user in original_approvers:
        delegations = ApproverDelegation.objects.filter(
            delegator=user,
            is_active=True,
            valid_from__lte=now,
            valid_until__gte=now,
        ).filter(
            models_Q_workflow_null_or_match(stage.workflow)
        )
        for d in delegations:
            delegates_set = set()
            delegates_set.add(d.delegate)
            approvers.update(delegates_set)

    return approvers


def can_user_act(instance, user):
    """Check if user can take action on the current stage of this instance."""
    if instance.status != 'pending' or not instance.current_stage:
        return False
    approvers = get_effective_approvers_for_stage(instance.current_stage)
    return user in approvers


def get_delegation_info(instance, actor):
    """
    If actor is a delegate, return the original approver they're acting for.
    Returns User or None.
    """
    now = timezone.now()
    stage = instance.current_stage
    if not stage:
        return None

    # Get direct approvers (without delegates)
    direct_approvers = set()
    for sa in stage.approvers.select_related('approver_user', 'approver_group').all():
        if sa.approver_user:
            direct_approvers.add(sa.approver_user)
        if sa.approver_group:
            direct_approvers.update(sa.approver_group.user_set.all())

    if actor in direct_approvers:
        return None  # Acting as themselves

    # Check if actor is a delegate for any direct approver
    for original in direct_approvers:
        if ApproverDelegation.objects.filter(
            delegator=original,
            delegate=actor,
            is_active=True,
            valid_from__lte=now,
            valid_until__gte=now,
        ).filter(models_Q_workflow_null_or_match(stage.workflow)).exists():
            return original

    return None


def process_action(instance, user, action, comment=''):
    """
    Process an approval action on a workflow instance.
    Returns (success: bool, message: str).
    """
    if instance.status != 'pending':
        return False, f"Instance is not pending (status: {instance.status})"

    if not instance.current_stage:
        return False, "No current stage"

    if not can_user_act(instance, user):
        return False, "You are not authorized to act on this stage"

    stage = instance.current_stage
    acted_on_behalf_of = get_delegation_info(instance, user)

    # Check if return is allowed for this stage
    if action == 'return' and not stage.allow_return:
        return False, "Return is not allowed at this stage"

    # Record the action
    WorkflowAction.objects.create(
        instance=instance,
        stage=stage,
        actor=user,
        acted_on_behalf_of=acted_on_behalf_of,
        action=action,
        comment=comment,
    )

    if action == 'approve':
        return _handle_approve(instance, stage)
    elif action == 'reject':
        return _handle_reject(instance)
    elif action == 'return':
        return _handle_return(instance, stage)
    else:
        return False, f"Unknown action: {action}"


def _is_stage_complete(instance, stage):
    """Check if all required approvals for a stage are satisfied."""
    actions = instance.actions.filter(stage=stage, action='approve')

    if stage.stage_type == 'sequential':
        return actions.exists()

    elif stage.stage_type == 'parallel_any':
        return actions.exists()

    elif stage.stage_type == 'parallel_all':
        # All direct approvers must have approved
        required = set()
        for sa in stage.approvers.all():
            if sa.approver_user:
                required.add(sa.approver_user_id)
            if sa.approver_group:
                required.update(sa.approver_group.user_set.values_list('id', flat=True))

        # Check that each required approver (or their delegate) has acted
        approved_by = set(actions.values_list('actor_id', flat=True))
        approved_on_behalf = set(actions.exclude(acted_on_behalf_of__isnull=True).values_list('acted_on_behalf_of_id', flat=True))
        covered = approved_by | approved_on_behalf
        return required.issubset(covered)

    return False


def _advance_to_next_stage(instance):
    """Move to the next stage or mark as approved if last stage."""
    current_order = instance.current_stage.order
    next_stage = instance.workflow.stages.filter(order__gt=current_order).order_by('order').first()

    if next_stage:
        instance.current_stage = next_stage
        instance.save()
        return True, f"Advanced to stage: {next_stage.name}"
    else:
        # Last stage — workflow is complete
        instance.status = 'approved'
        instance.current_stage = None
        instance.completed_at = timezone.now()
        instance.save()
        # Update the record's is_approved field
        _update_record_approval(instance, True)
        return True, "Workflow approved"


def _handle_approve(instance, stage):
    """Handle an approve action."""
    if _is_stage_complete(instance, stage):
        return _advance_to_next_stage(instance)
    else:
        return True, "Approval recorded, waiting for remaining approvers"


def _handle_reject(instance):
    """Handle a reject action — terminates the workflow."""
    instance.status = 'rejected'
    instance.current_stage = None
    instance.completed_at = timezone.now()
    instance.save()
    _update_record_approval(instance, False)
    return True, "Workflow rejected"


def _handle_return(instance, stage):
    """Handle a return action based on stage configuration."""
    if stage.return_to == 'previous_stage':
        prev_stage = instance.workflow.stages.filter(
            order__lt=stage.order
        ).order_by('-order').first()
        if prev_stage:
            instance.current_stage = prev_stage
            instance.status = 'pending'
            instance.save()
            # Clear actions for stages >= previous so they can re-approve
            instance.actions.filter(stage__order__gte=prev_stage.order).delete()
            return True, f"Returned to stage: {prev_stage.name}"
        else:
            # No previous stage — return to initiator = mark as returned
            instance.status = 'returned'
            instance.current_stage = None
            instance.completed_at = timezone.now()
            instance.save()
            return True, "Returned to initiator"

    elif stage.return_to == 'initiator':
        instance.status = 'returned'
        instance.current_stage = None
        instance.completed_at = timezone.now()
        instance.save()
        return True, "Returned to initiator"

    elif stage.return_to == 'specific_stage' and stage.return_to_stage:
        target = stage.return_to_stage
        instance.current_stage = target
        instance.status = 'pending'
        instance.save()
        instance.actions.filter(stage__order__gte=target.order).delete()
        return True, f"Returned to stage: {target.name}"

    # Fallback
    instance.status = 'returned'
    instance.completed_at = timezone.now()
    instance.save()
    return True, "Returned"


def _update_record_approval(instance, approved):
    """Update the is_approved field on the target record."""
    try:
        model_class = instance.content_type.model_class()
        record = model_class.objects.get(pk=instance.object_id)
        if hasattr(record, 'is_approved'):
            record.is_approved = approved
            record.save(update_fields=['is_approved'])
    except Exception:
        pass


def resubmit_workflow(instance, user):
    """Resubmit a rejected/returned workflow — creates a new attempt."""
    if instance.status not in ('rejected', 'returned'):
        return None, "Can only resubmit rejected or returned instances"

    # Check if resubmission is allowed for this workflow
    if not instance.workflow.allow_resubmission:
        return None, "Resubmission is not allowed for this workflow"

    model_class = instance.content_type.model_class()
    try:
        record = model_class.objects.get(pk=instance.object_id)
    except model_class.DoesNotExist:
        return None, "Record not found"

    new_instance = start_workflow(record, user, workflow=instance.workflow)
    if new_instance:
        WorkflowAction.objects.create(
            instance=new_instance,
            stage=new_instance.current_stage,
            actor=user,
            action='resubmit',
            comment=f'Resubmitted (attempt {new_instance.attempt})',
        )
    return new_instance, "Resubmitted successfully"


def get_pending_approvals(user):
    """Get all workflow instances where user can take action."""
    pending = WorkflowInstance.objects.filter(status='pending').select_related(
        'workflow', 'current_stage', 'content_type'
    )
    result = []
    for instance in pending:
        if instance.current_stage and can_user_act(instance, user):
            result.append(instance)
    return result
