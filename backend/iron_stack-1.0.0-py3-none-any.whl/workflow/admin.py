from django.contrib import admin
from workflow.models import (
    Workflow, WorkflowStage, StageApprover,
    ApproverDelegation, WorkflowInstance, WorkflowAction,
)

admin.site.register(Workflow)
admin.site.register(WorkflowStage)
admin.site.register(StageApprover)
admin.site.register(ApproverDelegation)
admin.site.register(WorkflowInstance)
admin.site.register(WorkflowAction)
