import os

from django.conf import settings

from api.utils.logging import init_logging

s3_logger = init_logging(log_name='S3_LOGS', log_directory=os.path.join(settings.BASE_DIR, 'logs'))

ldap_auth_logger = init_logging(log_name='LDAP_AUTH_LOGS', log_directory=os.path.join(settings.BASE_DIR, 'logs'))
