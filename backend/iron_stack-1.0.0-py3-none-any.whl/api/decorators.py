from django.core.cache import cache
from rest_framework.response import Response


def cache_model_api_response(f):
    def wrapper(*args, **kwargs):
        self = args[0]
        request = args[1]

        if request.query_params.get('cache_bust', None):
            cache.delete(self.model.api_config['cache_config']['key'])

        if 'cache_config' in self.model.api_config:
            cache_config = self.model.api_config['cache_config']
            cached_data = cache.get(cache_config['key'])
            if cached_data:
                return Response(cached_data)

        response = f(*args, **kwargs)
        if 'cache_config' in self.model.api_config:
            cache_config = self.model.api_config['cache_config']
            cache.set(cache_config['key'], response.data, cache_config['timeout'])
        return response

    return wrapper
