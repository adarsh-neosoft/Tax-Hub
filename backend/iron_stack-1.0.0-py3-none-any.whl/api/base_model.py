from django.db import models
from django.contrib.auth.models import User
from .base_manager import BaseManager

class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='%(class)s_created_by')
    last_updated_at = models.DateTimeField(auto_now=True)
    last_updated_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='%(class)s_last_updated_by')
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)
    objects = BaseManager()

    class Meta:
        abstract = True