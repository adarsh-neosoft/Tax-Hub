from datetime import timedelta, datetime


def str2bool(v):
    return v.lower() in ("yes", "true", "t", "1")


def parse_query_params(value):
    filter_operator1 = None
    filter_operator2 = None
    if '.' in value:
        filter_operator1 = value.split('.', 1)[1]
        if '.' in filter_operator1:
            [filter_operator1, filter_operator2] = value.split('.')[1:]
    filter_field = value.split('.', 1)[0]

    return filter_field, filter_operator1, filter_operator2


def determine_filter_key_value(field_type, filter_field, filter_value, operator1, operator2):
    if field_type == 'BooleanField':
        return filter_field, str2bool(filter_value)
    elif field_type == 'ForeignKey':
        if operator1 and operator2:
            return f"{filter_field}__{operator1}__{operator2}", filter_value
        elif operator1:
            return f"{filter_field}__{operator1}", filter_value
        else:
            return f"{filter_field}", filter_value
    elif field_type == 'DateTimeField':
        if operator1:
            return f"{filter_field}__date__{operator1}", filter_value
        else:
            return f"{filter_field}__date", filter_value
    else:
        if operator1:
            return f"{filter_field}__{operator1}", filter_value
        else:
            return f"{filter_field}", filter_value


def format_datetime_friendly(datetime_string, now_override=None):
    """
    Converts a datetime string into a user-friendly, relative format (e.g.,
    '5 minutes ago', 'yesterday at 10:30 AM', or a full date).

    Args:
        datetime_string (str): The datetime string to convert. It attempts to
                               parse either 'YYYY-MM-DDTHH:MM:SS.ffffffZ' (ISO 8601)
                               or 'YYYY-MM-DD' (Date Only).
        now_override (datetime.datetime, optional): A specific time to use as
                                                    'now' for testing purposes.
                                                    Defaults to the current time.

    Returns:
        str: A user-friendly string representation of the time.
    """
    # Define the expected input formats
    ISO_DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
    DATE_ONLY_FORMAT = '%Y-%m-%d'
    dt_object = None

    try:
        # 1. Attempt to parse as full ISO 8601 datetime
        dt_object = datetime.strptime(datetime_string, ISO_DATETIME_FORMAT)
    except ValueError:
        try:
            # 2. If full datetime fails, attempt to parse as date only
            dt_object = datetime.strptime(datetime_string, DATE_ONLY_FORMAT)
        except ValueError as e:
            # 3. If both fail, return an error message
            return f"Error: Invalid datetime format. Expected '{ISO_DATETIME_FORMAT}' or '{DATE_ONLY_FORMAT}'. {e}"

    # 2. Define 'now' (or use the override for testing)
    now = now_override if now_override is not None else datetime.now()

    # 3. Calculate the time difference (timedelta)
    delta = now - dt_object

    # --- Relative Time Logic ---

    # Future time handling (optional but good practice)
    if delta.total_seconds() < 0:
        # Use abs() to calculate the difference to the future time
        future_delta = abs(delta)

        # Less than 1 minute from now
        if future_delta < timedelta(minutes=1):
            return "in a moment"
        # Minutes from now
        elif future_delta < timedelta(hours=1):
            minutes = int(future_delta.total_seconds() // 60)
            return f"in {minutes} minute{'s' if minutes > 1 else ''}"
        # Hours from now
        elif future_delta < timedelta(days=1):
            hours = int(future_delta.total_seconds() // 3600)
            return f"in {hours} hour{'s' if hours > 1 else ''}"
        # Tomorrow
        elif future_delta < timedelta(days=2) and dt_object.date() == (now.date() + timedelta(days=1)):
            return f"tomorrow at {dt_object.strftime('%I:%M %p').lstrip('0')}"
        # Default full date for future dates
        else:
            return dt_object.strftime('%B %d, %Y')

    # Past time handling (Standard 'X ago' format)

    # Less than 1 minute ago
    if delta < timedelta(minutes=1):
        return "just now"

    # Minutes ago
    elif delta < timedelta(hours=1):
        minutes = int(delta.total_seconds() // 60)
        return f"{minutes} minute{'s' if minutes > 1 else ''} ago"

    # Hours ago (within the last 24 hours)
    elif delta < timedelta(days=1):
        hours = int(delta.total_seconds() // 3600)
        # Check if the datetime object is on the same calendar day as now
        if dt_object.date() == now.date():
            # If same day, check if time component was 00:00:00 (i.e., date only input)
            if dt_object.hour == 0 and dt_object.minute == 0 and dt_object.second == 0:
                return "today"  # Simpler output for date-only input
            # If same day and has time, show the time
            return f"today at {dt_object.strftime('%I:%M %p').lstrip('0')}"
        else:
            # If it's a different day, but still within 24 hours (e.g., 2 AM today, time is 1 AM yesterday)
            # Or if it's strictly yesterday
            return f"yesterday at {dt_object.strftime('%I:%M %p').lstrip('0')}"


    # Days ago (up to 7 days)
    elif delta < timedelta(days=7):
        days = int(delta.total_seconds() // 86400)
        # Simple count, e.g., "2 days ago"
        return f"{days} day{'s' if days > 1 else ''} ago"

    # Weeks ago (up to 30 days)
    elif delta < timedelta(days=30):
        weeks = int(delta.total_seconds() // (86400 * 7))
        return f"{weeks} week{'s' if weeks > 1 else ''} ago"

    # Older than 30 days - show the standard full date format
    else:
        return dt_object.strftime('%B %d, %Y')


def dict_diff(dict_old, dict_new):
    """
    Compares two dictionaries and returns a dictionary detailing the differences.

    Args:
        dict_old (dict): The original (baseline) dictionary.
        dict_new (dict): The new dictionary to compare against.

    Returns:
        dict: A dictionary containing 'added', 'changed', and 'removed' keys.
    """
    diff_result = {
        'added': {},  # Key-values present in dict_new but not dict_old
        'changed': {},  # Keys in both, but with different values
        'removed': {}  # Key-values present in dict_old but not dict_new
    }

    # Get the sets of keys
    keys_old = set(dict_old.keys())
    keys_new = set(dict_new.keys())

    # 1. Keys added (New key-values)
    keys_added = keys_new - keys_old
    for key in keys_added:
        if getattr(dict_new[key], 'file', None):
            diff_result['added'][key] = dict_new[key].name.split('/')[-1]
        else:
            diff_result['added'][key] = dict_new[key]

    # 2. Keys removed
    keys_removed = keys_old - keys_new
    for key in keys_removed:
        diff_result['removed'][key] = dict_old[key]

    # 3. Keys changed (Common keys with different values)
    keys_common = keys_old.intersection(keys_new)
    for key in keys_common:
        old_value = dict_old[key]
        new_value = dict_new[key]
        if getattr(old_value, 'file', None) or getattr(new_value, 'file', None):
            old_value = dict_old[key].name.split('/')[-1]
            new_value = dict_new[key].name.split('/')[-1]
        if old_value != new_value:
            diff_result['changed'][key] = {
                'old': str(old_value),
                'new': str(new_value)
            }

    return diff_result
