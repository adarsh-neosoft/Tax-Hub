from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.models import Permission, User
from rest_framework.exceptions import PermissionDenied
from rest_framework.fields import empty
from rest_framework.serializers import ModelSerializer
from rest_framework_simplejwt.serializers import TokenObtainSerializer
from rest_framework_simplejwt.tokens import RefreshToken

from .authentication import LDAPAuthenticator


class BaseSerializer(ModelSerializer):
    request_method_permission_codename_mapping = {
        "post": "add_{}",
        "patch": "change_{}",
        "put": "change_{}",
        "delete": "delete_{}",
        "get": "view_{}",
    }

    def __init__(self, instance=None, data=empty, request=None, **kwargs):
        super().__init__(instance, data, **kwargs)
        if request is None and 'context' in kwargs:
            request = kwargs.get('context').get('request', None)
        self.request = request
        if not self.is_authorized():
            raise PermissionDenied()

    def is_authorized(self):
        """
        Checking if a user has permissions to access this model
        Permission should be assigned to the user or to the assigned groups
        """
        request_method = self.request.method.lower() if self.request else None
        user = self.request.user if self.request else None
        user_groups = user.groups.all() if user else []

        model_name = self.Meta.model.__name__.lower().replace(" ", "")

        if request_method not in self.request_method_permission_codename_mapping.keys():
            return True

        permission_codename = self.request_method_permission_codename_mapping[request_method].format(model_name)

        # Checking if user groups have permissions assigned or not
        for each in user_groups:
            if each.permissions.filter(codename=permission_codename).exists():
                return True

        # Checking if a user has direct permissions assigned
        if Permission.objects.filter(user__username=user.username, codename=permission_codename).exists():
            return True

        return False


class CustomTokenObtainPairSerializer(TokenObtainSerializer):
    token_class = RefreshToken
    user = None

    def validate(self, attrs):
        AUTH_SETTINGS = settings.FRAMEWORK_SETTINGS['AUTHENTICATION']
        kwargs = {
            self.username_field: attrs[self.username_field].lower(),
            "password": attrs["password"],
        }

        if AUTH_SETTINGS['LDAP_AUTH']:
            ldap_response = LDAPAuthenticator().authenticate(username=kwargs['username'], password=kwargs['password'])
            if ldap_response['authenticated']:
                if AUTH_SETTINGS['AUTO_USER_CREATION']:
                    self.user, _ = User.objects.get_or_create(username=kwargs['username'])
                else:
                    self.user = User.objects.get(username__iexact=kwargs['username'])
            else:
                return {
                    "is_authenticated": False,
                    "message": "Invalid Credentials"
                }
        else:
            if User.objects.filter(username__iexact=kwargs['username']).exists():
                self.user = authenticate(username=kwargs['username'], password=kwargs['password'])

            elif AUTH_SETTINGS['AUTO_USER_CREATION']:
                self.user = User.objects.create(username=kwargs['username'])
                self.user.set_password(kwargs["password"])
                self.user.save()
            else:
                return {
                    "is_authenticated": False,
                    "message": "Invalid Credentials"
                }

        if self.user and self.user.is_active:
            refresh = self.get_token(self.user)
            return {
                "is_authenticated": True,
                "message": "Login Successful",
                "refresh": str(refresh),
                "access": str(refresh.access_token),
            }
        else:
            return {
                "is_authenticated": False,
                "message": "Invalid Credentials"
            }
