import copy
import os

import pandas as pd
from django.apps import apps
from django.conf import settings
from django.db.models import Q
from django.http import HttpResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView, ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.serializers import ModelSerializer
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

from api.authentication import get_assigned_model_permissions
from api.decorators import cache_model_api_response
from api.helpers import parse_query_params, determine_filter_key_value
from api.serializers import BaseSerializer
from api.utils.encryption_utils import encrypt, decrypt
from api.utils.s3_service import S3Service


def _build_generic_serializer(model_cls):
    """
    Build a ModelSerializer class bound to `model_cls` that:
    - auto-injects request.user into created_by / last_updated_by
    - encrypts fields listed in model.model_config['encrypted_fields']
    - uploads file-valued fields to S3 (falling back to local MEDIA_ROOT on failure)
    - decrypts encrypted fields on output
    """

    class GenericSerializer(BaseSerializer):

        class Meta:
            model = model_cls
            fields = '__all__'
            read_only_fields = ('created_by', 'last_updated_by')

        def save(self, **kwargs):
            # Stash file-valued data so it is not fed through the normal model save;
            # we will persist those via S3/local storage after the row exists.
            new_data = self.validated_data.copy()
            file_fields = {
                name: value for name, value in new_data.items()
                if getattr(value, 'file', None)
            }
            for name in file_fields:
                self.validated_data[name] = None

            # Encrypt configured fields in place.
            for field_name in self.Meta.model.model_config.get('encrypted_fields', []) or []:
                if field_name in self.validated_data and self.validated_data[field_name] is not None:
                    self.validated_data[field_name] = encrypt(
                        self.validated_data[field_name], settings.SECRET_KEY
                    )

            # Inject audit user.
            user = self.request.user if self.request is not None else None
            if user is not None and user.is_authenticated:
                if self.instance is None:
                    kwargs.setdefault('created_by', user)
                kwargs.setdefault('last_updated_by', user)

            # Capture state before save for audit logging
            is_update = self.instance is not None and self.instance.pk is not None
            old_data = None
            m2m_old_data = {}
            m2m_new_data = {}
            old_file_data = {}
            if hasattr(self.Meta.model, 'model_config'):
                exclude = self.Meta.model.model_config.get('exclude_from_audit_log', []) or []
                # Capture M2M new values from validated_data BEFORE super().save() pops them
                for key in list(new_data.keys()):
                    try:
                        field_obj = self.Meta.model._meta.get_field(key)
                    except Exception:
                        continue
                    if field_obj.many_to_many:
                        # M2M values in validated_data are model instances or PKs
                        m2m_val = new_data.get(key, []) or []
                        m2m_new_data[key] = sorted([
                            item.pk if hasattr(item, 'pk') else int(item) for item in m2m_val
                        ])

                # Capture old file names before save nulls them out
                if is_update:
                    for key in file_fields:
                        old_file_val = getattr(self.instance, key, None)
                        old_file_data[key] = old_file_val.name if old_file_val else ''

                if is_update:
                    old_data = {}
                    encrypted_fields = self.Meta.model.model_config.get('encrypted_fields', []) or []
                    for key in new_data:
                        if key in exclude or key in file_fields:
                            continue
                        try:
                            field_obj = self.Meta.model._meta.get_field(key)
                        except Exception:
                            old_data[key] = getattr(self.instance, key, None)
                            continue
                        if field_obj.many_to_many:
                            m2m_old_data[key] = sorted(
                                getattr(self.instance, key).values_list('id', flat=True)
                            )
                        elif field_obj.many_to_one or field_obj.one_to_one:
                            old_data[key] = getattr(self.instance, f'{key}_id', None)
                        else:
                            val = getattr(self.instance, key, None)
                            # Decrypt encrypted fields so we compare plaintext to plaintext
                            if key in encrypted_fields and val:
                                val = decrypt(val, settings.SECRET_KEY)
                            old_data[key] = val

            super().save(**kwargs)

            # Create audit log entry
            if user and hasattr(self.Meta.model, 'model_config'):
                try:
                    import json
                    from django.contrib.admin.models import LogEntry, ADDITION, CHANGE
                    from django.contrib.contenttypes.models import ContentType as CT

                    ct_id = CT.objects.get_for_model(self.instance).pk

                    if not is_update:
                        # New record: log creation with field values
                        added_data = {}
                        for k, v in new_data.items():
                            if k in file_fields:
                                added_data[k] = file_fields[k].name if hasattr(file_fields[k], 'name') else str(file_fields[k])
                                continue
                            if isinstance(v, list):
                                added_data[k] = ', '.join(str(item.pk if hasattr(item, 'pk') else item) for item in v)
                            elif hasattr(v, 'pk'):
                                added_data[k] = str(v.pk)
                            else:
                                added_data[k] = str(v) if v is not None else ''
                        # Include M2M
                        for k, ids in m2m_new_data.items():
                            added_data[k] = ', '.join(str(i) for i in ids)
                        LogEntry.objects.log_action(
                            user_id=user.pk,
                            content_type_id=ct_id,
                            object_id=self.instance.pk,
                            object_repr=str(self.instance),
                            action_flag=ADDITION,
                            change_message=json.dumps({'added': added_data}),
                        )
                    elif old_data is not None:
                        # Update: compute diff for regular + FK fields
                        exclude = self.Meta.model.model_config.get('exclude_from_audit_log', []) or []
                        changes = {'changed': {}, 'added': {}, 'removed': {}}

                        for key, old_val in old_data.items():
                            if key in exclude:
                                continue
                            new_val = new_data.get(key)
                            # Normalize: FK sends ID as int, old is also int
                            if new_val is not None and old_val is not None:
                                # Compare as strings for safety
                                if str(old_val) != str(new_val):
                                    changes['changed'][key] = {'old': str(old_val), 'new': str(new_val)}
                            elif old_val != new_val:
                                changes['changed'][key] = {'old': str(old_val or ''), 'new': str(new_val or '')}

                        # M2M diff: compare ID lists
                        for key, old_ids in m2m_old_data.items():
                            new_ids = m2m_new_data.get(key, [])
                            if old_ids != new_ids:
                                changes['changed'][key] = {
                                    'old': ', '.join(str(i) for i in old_ids),
                                    'new': ', '.join(str(i) for i in new_ids),
                                }

                        # File field diff
                        for key, file_obj in file_fields.items():
                            if key in exclude:
                                continue
                            old_name = old_file_data.get(key, '')
                            new_name = file_obj.name if hasattr(file_obj, 'name') else str(file_obj)
                            if old_name.split('/')[-1] != new_name.split('/')[-1]:
                                changes['changed'][key] = {
                                    'old': old_name.split('/')[-1] if old_name else '(none)',
                                    'new': new_name.split('/')[-1] if new_name else '(none)',
                                }

                        if changes['changed'] or changes['added'] or changes['removed']:
                            LogEntry.objects.log_action(
                                user_id=user.pk,
                                content_type_id=ct_id,
                                object_id=self.instance.pk,
                                object_repr=str(self.instance),
                                action_flag=CHANGE,
                                change_message=json.dumps(changes),
                            )
                except Exception:
                    pass  # Don't let audit logging break the save

            # Persist file fields now that we have a PK.
            for field_name, file_obj in file_fields.items():
                self._persist_file_field(field_name, file_obj)

        def _persist_file_field(self, field_name, file_obj):
            file_copy = copy.deepcopy(file_obj)
            upload_to = self.instance._meta.get_field(field_name).upload_to
            file_path = upload_to(self.instance, file_obj.name)
            s3_key = f"{settings.PROJECT_NAME}/{self.instance._meta.app_label}/{file_path}"
            try:
                bucket = settings.FRAMEWORK_SETTINGS['AWS']['BUCKET_NAME']
                uploaded_path = S3Service(bucket).upload(file_obj, s3_key)
                setattr(self.instance, field_name, uploaded_path)
                self.instance.save()
            except Exception:
                try:
                    local_path = os.path.join(settings.MEDIA_ROOT, file_path)
                    os.makedirs(os.path.dirname(local_path), exist_ok=True)
                    with open(local_path, "wb+") as f:
                        for chunk in file_copy.chunks():
                            f.write(chunk)
                    setattr(self.instance, field_name, local_path)
                    self.instance.save()
                except IOError as e:
                    print(f"Error saving file: {e}")

        def to_representation(self, instance):
            data = super().to_representation(instance)

            # Resolve related field values (e.g. 'created_by.username')
            for each in instance.api_config.get('include_related_field_values', []) or []:
                if '.' in each:
                    field, related_field = each.split('.')
                    fk_id = data.get(field)
                    if fk_id is not None:
                        related_model = instance._meta.get_field(field).related_model
                        try:
                            related_obj = related_model.objects.get(pk=fk_id)
                            data[each] = getattr(related_obj, related_field, None)
                        except related_model.DoesNotExist:
                            data[each] = None

            # Decrypt encrypted fields
            for field_name in instance.model_config.get('encrypted_fields', []) or []:
                if data.get(field_name):
                    data[field_name] = decrypt(data[field_name], settings.SECRET_KEY)
            return data

    return GenericSerializer


class GenericAPIView(APIView):
    model = None
    permission_classes = [IsAuthenticated]

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)
        self.model = apps.get_model(app_label=kwargs['app_label'], model_name=kwargs['model_name'])

    def get_queryset(self):
        qs = self.model.objects.all()
        if self.request.query_params:
            query_dict = self.request.query_params.dict()
            filter_query = {}
            filter_fields = self.model.api_config.get('filter_fields', [])

            for param_key in query_dict:
                # Parse the query param: field.operator1.operator2
                filter_field, filter_operator1, filter_operator2 = parse_query_params(param_key)

                # Check if this field (possibly dotted) is in filter_fields.
                # For dotted fields like 'created_by.username', the param_key from
                # the frontend will be 'created_by.username.icontains' — so filter_field
                # is 'created_by' and operator1 is 'username' and operator2 is 'icontains'.
                # We need to check if 'created_by.username' is in filter_fields.
                dotted_field = f"{filter_field}.{filter_operator1}" if filter_operator1 else filter_field

                if dotted_field in filter_fields:
                    # This is a dotted FK field filter (e.g. created_by.username)
                    # Convert to Django ORM lookup: created_by__username__operator
                    orm_field = dotted_field.replace('.', '__')
                    filter_value = query_dict[param_key]
                    if filter_operator2:
                        filter_query[f"{orm_field}__{filter_operator2}"] = filter_value
                    else:
                        filter_query[orm_field] = filter_value
                elif filter_field in filter_fields:
                    # Regular (non-dotted) field filter
                    try:
                        model_field = self.model._meta.get_field(filter_field)
                        field_type = model_field.__class__.__name__
                    except Exception:
                        field_type = 'CharField'
                    filter_value = query_dict[param_key]
                    key, value = determine_filter_key_value(
                        field_type, filter_field, filter_value, filter_operator1, filter_operator2
                    )
                    filter_query[key] = value

            if filter_query:
                qs = qs.filter(**filter_query)

            if 'search' in query_dict:
                q_objects = Q()
                search_term = query_dict['search']
                search_fields = []
                for each in self.model.api_config['search_fields']:
                    if '.' in each:
                        field, related_field = each.split('.')
                        search_fields.append(f'{field}__{related_field}__icontains')
                    else:
                        search_fields.append(each + '__icontains')
                for field in search_fields:
                    q_objects |= Q(**{field: search_term})
                qs = qs.filter(q_objects)
        return qs

    def get_serializer_class(self):
        return _build_generic_serializer(self.model)

    def options(self, request, *args, **kwargs):
        """
        Extend the default OPTIONS response with display config, filter_fields,
        and relation metadata (FK/M2M dropdown paths) from the model.
        """
        response = super().options(request, *args, **kwargs)
        if hasattr(self.model, 'api_config'):
            api_config = self.model.api_config
            if api_config.get('list_display_fields'):
                response.data['list_display_fields'] = api_config['list_display_fields']
            if api_config.get('form_display_fields'):
                response.data['form_display_fields'] = api_config['form_display_fields']
            if api_config.get('filter_fields'):
                response.data['filter_fields'] = api_config['filter_fields']

        # Build relation metadata so the frontend knows where to fetch dropdowns
        relations = {}
        for field in self.model._meta.get_fields():
            if field.many_to_one or field.one_to_one:
                # ForeignKey / OneToOne — field.name is the FK field name
                related_model = field.related_model
                relations[field.name] = {
                    'type': 'fk',
                    'app_label': related_model._meta.app_label,
                    'model_name': related_model._meta.model_name,
                    'dropdown_path': f"{related_model._meta.app_label}/{related_model._meta.model_name}/dropdown",
                }
            elif field.many_to_many and not field.auto_created:
                # ManyToMany (only the forward side, not reverse)
                related_model = field.related_model
                relations[field.name] = {
                    'type': 'm2m',
                    'app_label': related_model._meta.app_label,
                    'model_name': related_model._meta.model_name,
                    'dropdown_path': f"{related_model._meta.app_label}/{related_model._meta.model_name}/dropdown",
                }

        if relations:
            response.data['relations'] = relations

        return response

    def delete(self, request, *args, **kwargs):
        self.model.objects.filter(pk=kwargs['pk']).update(is_deleted=True, is_active=False)
        return Response({'message': 'Successfully deleted'})


class GenericObjectAPIView(GenericAPIView, RetrieveUpdateDestroyAPIView):
    pass


class GenericListAPIView(GenericAPIView, ListCreateAPIView):
    @cache_model_api_response
    def get(self, request, *args, **kwargs):
        qs = self.get_queryset()
        serializer = self.get_serializer(qs, many=True)
        if self.request.query_params:
            query_dict = self.request.query_params.dict()
            if 'download' in query_dict:
                df = pd.DataFrame(serializer.data)
                return HttpResponse(df.to_csv(index=False), content_type='text/csv')
        return super().get(request, *args, **kwargs)


class GenericDropdownAPIView(GenericAPIView, ListAPIView):
    """
    Returns a lightweight list of records for use in dropdowns/selects.
    - No pagination (flat array)
    - Limited to 50 results by default (use ?search= to narrow)
    - Only returns id + dropdown_fields
    """
    allowed_methods = ['GET']
    pagination_class = None
    MAX_DROPDOWN_RESULTS = 10

    def get_queryset(self):
        qs = self.model.objects.all()

        # Allow overriding dropdown fields via query params (from inline FK config)
        fields_param = self.request.query_params.get('fields')
        search_fields_param = self.request.query_params.get('search_fields')

        dropdown_fields = self.model.api_config.get('dropdown_fields', []) if not fields_param else fields_param.split(',')

        # Optimize FK lookups
        fk_fields = [f.split('.')[0] for f in dropdown_fields if '.' in f]
        if fk_fields:
            qs = qs.select_related(*fk_fields)

        # Support search — use search_fields param if provided, otherwise use dropdown_fields
        search = self.request.query_params.get('search')
        if search:
            from django.db.models import Q
            q_objects = Q()
            search_on = search_fields_param.split(',') if search_fields_param else dropdown_fields
            for field_name in search_on:
                if '.' in field_name:
                    fk, related = field_name.split('.')
                    q_objects |= Q(**{f"{fk}__{related}__icontains": search})
                else:
                    q_objects |= Q(**{f"{field_name}__icontains": search})
            qs = qs.filter(q_objects)

        return qs[:self.MAX_DROPDOWN_RESULTS]

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_serializer_class(self):
        model_cls = self.model
        # Read the fields param to override dropdown_fields in serializer
        fields_param = self.request.query_params.get('fields')
        override_fields = fields_param.split(',') if fields_param else None

        class GenericDropdownSerializer(ModelSerializer):
            class Meta:
                model = model_cls
                fields = '__all__'

            def to_representation(self, instance):
                data = super().to_representation(instance)
                dropdown_fields = override_fields or instance.api_config.get('dropdown_fields') or []
                if not dropdown_fields:
                    # No config at all — just return id + first string field
                    filtered = {'id': data.get('id')}
                    for k, v in data.items():
                        if k != 'id' and isinstance(v, str) and v:
                            filtered[k] = v
                            break
                    return filtered if len(filtered) > 1 else data

                filtered_data = {'id': data.get('id')}
                filtered_data.update({k: v for k, v in data.items() if k in dropdown_fields})
                for each in dropdown_fields:
                    if '.' in each:
                        field, related_field = each.split('.')
                        related_obj = getattr(instance, field, None)
                        if related_obj:
                            filtered_data[each] = getattr(related_obj, related_field, None)
                        else:
                            filtered_data[each] = None
                    elif each in (instance.model_config.get('encrypted_fields') or []):
                        if filtered_data.get(each):
                            filtered_data[each] = decrypt(filtered_data[each], settings.SECRET_KEY)
                return filtered_data

        return GenericDropdownSerializer


class DefaultView(APIView):
    permission_classes = [IsAuthenticated]

    def options(self, request, *args, **kwargs):
        """
        For generating ui sections/subsections along with permissions
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        ui_config = copy.deepcopy(settings.FRAMEWORK_SETTINGS['UI_CONFIG'])
        nav_items = ui_config['NAVIGATION_ITEMS']
        nav_by_title = {item['title']: item for item in nav_items if 'title' in item}

        for app_label in settings.PROJECT_APPS:
            for _model_name, model in apps.all_models[app_label].items():
                if not hasattr(model, 'ui_config'):
                    continue
                model_ui_config = model.ui_config.copy()
                model_ui_config['permissions'] = get_assigned_model_permissions(request.user, model)

                nav_header = model_ui_config.pop('navigation_header', None)
                if nav_header and nav_header in nav_by_title:
                    parent = nav_by_title[nav_header]
                    parent.setdefault('items', []).append(model_ui_config)
                else:
                    nav_items.append(model_ui_config)
                    nav_by_title[model_ui_config.get('title', '')] = model_ui_config

        return Response(ui_config)


@method_decorator(csrf_exempt, name='dispatch')
class TokenObtainPairCustomView(TokenObtainPairView):

    def post(self, request: Request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        response.status_code = 200 if response.data['is_authenticated'] else 401
        return response


class LogoutView(APIView):
    """
    Invalidates the refresh token supplied in the request body.
    With the token_blacklist app installed, the token is blacklisted.
    Without it, the call still succeeds and the client is expected to
    discard its tokens.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        refresh = request.data.get('refresh')
        if refresh:
            try:
                RefreshToken(refresh).blacklist()
            except TokenError:
                # Token already expired or malformed; treat as logged out.
                pass
            except AttributeError:
                # token_blacklist app not installed; stateless logout.
                pass
        return Response({'message': 'Logout successful'})


class AuditLogView(APIView):
    """Retrieve audit log (change history) for a specific record."""
    permission_classes = [IsAuthenticated]

    def get(self, request, app_label, model_name, object_id):
        import json
        from django.contrib.admin.models import LogEntry
        from django.contrib.contenttypes.models import ContentType

        try:
            ct = ContentType.objects.get(app_label=app_label, model=model_name)
        except ContentType.DoesNotExist:
            return Response({'detail': 'Model not found'}, status=404)

        entries = LogEntry.objects.filter(
            content_type=ct,
            object_id=str(object_id),
        ).select_related('user').order_by('-action_time')[:50]

        result = []
        for entry in entries:
            try:
                changes = json.loads(entry.change_message) if entry.change_message else {}
            except (json.JSONDecodeError, TypeError):
                changes = {'message': entry.change_message}

            result.append({
                'id': entry.id,
                'user': entry.user.get_full_name() or entry.user.username,
                'action': 'Created' if entry.action_flag == 1 else 'Updated' if entry.action_flag == 2 else 'Deleted',
                'changes': changes,
                'timestamp': entry.action_time.isoformat(),
            })

        return Response(result)
