from django.conf import settings
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from ldap3 import Server, Connection, AUTO_BIND_NO_TLS
from ldap3.core.exceptions import LDAPBindError, LDAPInvalidCredentialsResult, LDAPSocketOpenError
from rest_framework import permissions

from api.logger import ldap_auth_logger


class IsAuthorized(permissions.BasePermission):

    def has_permission(self, request, view):
        """
        Checking if a user has permissions to access this viewset,
        Permission should be assigned to the user or to the assigned groups
        Example:
            get_customerdetails_view
            post_customerregistration_view
            put_customerupdate_view
            delete_customerfile_view
        """

        view_name = view.__class__.__name__.lower()
        request_method = request.method.lower()
        permission_codename = request_method + "_" + view_name + "_view"

        user = request.user
        user_groups = user.groups.all()

        # Checking if user groups have permissions assigned or not
        for each in user_groups:
            if each.permissions.filter(codename=permission_codename).exists():
                return True

        # Checking if a user has direct permissions assigned
        if Permission.objects.filter(user__username=user.username, codename=permission_codename).exists():
            return True

        return False


def get_assigned_model_permissions(user, model):
    user_groups = user.groups.all()
    permission_codenames = []
    content_type = ContentType.objects.get_for_model(model)
    for each in user_groups:
        permission_codenames.extend(
            each.permissions.filter(content_type=content_type).values_list('codename', flat=True))
    user_permissions = user.user_permissions.filter(content_type=content_type).values_list('codename', flat=True)
    permission_codenames.extend(user_permissions)
    return list(set(permission_codenames))


class LDAPAuthenticator:
    servers = settings.FRAMEWORK_SETTINGS['AUTHENTICATION']['LDAP_SERVERS']

    def authenticate(self, username, password):
        """
        Authenticates the user against LDAP Servers
        :param username: LDAP Username
        :param password: LDAP Password
        :return: Dictionary containing authentication status and server details
        """

        for each in self.servers:
            try:
                ldap_server = Server(each['hostname'], each['port'], connect_timeout=10)
                ldap_auth_logger.info(f"Trying to connect to LDAP Server: {each['hostname']} with username: {username}")
                conn = Connection(
                    ldap_server,
                    auto_bind=AUTO_BIND_NO_TLS,
                    check_names=True,
                    user='myamns\\' + str(username),
                    password=password,
                    raise_exceptions=True
                )
                if conn.bind():
                    ldap_auth_logger.info(
                        f"Login Successful for LDAP Server: {each['hostname']} with username: {username}")
                    return {
                        "authenticated": True,
                        "server": each['hostname'],
                        "message": "Login Successful",
                        "log": [{
                            "response": conn.response,
                            "message": conn.result
                        }]
                    }
            except (LDAPBindError, LDAPSocketOpenError):
                ldap_auth_logger.error(
                    f"Failed to connect to LDAP Server: {each['hostname']} with username: {username}")
                ldap_auth_logger.exception(f"Exception: {str(LDAPBindError)}")
            except LDAPInvalidCredentialsResult:
                ldap_auth_logger.error(
                    f"Invalid Credentials for LDAP Server: {each['hostname']} with username: {username}")
                return {
                    "authenticated": False,
                    "server": each['hostname'],
                    "message": "Invalid Credentials",
                    "log": [{
                        "Error": "Invalid Credentials",
                        "Exception": str(LDAPInvalidCredentialsResult)
                    }]
                }
            else:
                ldap_auth_logger.error(f"Unknown Error for LDAP Server: {each['hostname']} with username: {username}")
                return {
                    "authenticated": False,
                    "server": each['hostname'],
                    "message": "Unknown Error",
                    "log": [{
                        "Error": "Unknown Error",
                        "Exception": "Unknown Exception"
                    }]
                }
        return None
