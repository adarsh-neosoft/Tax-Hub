"""
Role-Based Access Control (RBAC) API views.

Provides endpoints for managing Users, Groups, and Permissions through the
framework UI instead of Django Admin.
"""
from django.contrib.auth.models import User, Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.db import models
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from api.rbac_serializers import (
    UserListSerializer,
    UserDetailSerializer,
    UserCreateSerializer,
    GroupListSerializer,
    GroupDetailSerializer,
    PermissionSerializer,
)


class UserListView(APIView):
    """List all users or create a new user."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        users = User.objects.all().order_by('username')
        search = request.query_params.get('search')
        if search:
            users = users.filter(username__icontains=search)
        serializer = UserListSerializer(users, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = UserCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(UserDetailSerializer(user).data, status=status.HTTP_201_CREATED)


class UserDetailView(APIView):
    """Retrieve, update, or deactivate a user."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'detail': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = UserDetailSerializer(user)
        return Response(serializer.data)

    def patch(self, request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'detail': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        data = request.data
        if 'username' in data:
            user.username = data['username']
        if 'email' in data:
            user.email = data['email']
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'is_active' in data:
            user.is_active = data['is_active']
        if 'is_staff' in data:
            user.is_staff = data['is_staff']
        if 'password' in data and data['password']:
            user.set_password(data['password'])
        if 'groups' in data:
            group_ids = data['groups']
            user.groups.set(Group.objects.filter(pk__in=group_ids))
        if 'user_permissions' in data:
            perm_ids = data['user_permissions']
            user.user_permissions.set(Permission.objects.filter(pk__in=perm_ids))
        user.save()
        return Response(UserDetailSerializer(user).data)

    def delete(self, request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'detail': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        user.is_active = False
        user.save()
        return Response({'message': 'User deactivated'})


class GroupListView(APIView):
    """List all groups or create a new group."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        groups = Group.objects.all().order_by('name')
        search = request.query_params.get('search')
        if search:
            groups = groups.filter(name__icontains=search)
        serializer = GroupListSerializer(groups, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = GroupDetailSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        group = serializer.save()
        return Response(GroupDetailSerializer(group).data, status=status.HTTP_201_CREATED)


class GroupDetailView(APIView):
    """Retrieve, update, or delete a group."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request, pk):
        try:
            group = Group.objects.get(pk=pk)
        except Group.DoesNotExist:
            return Response({'detail': 'Group not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = GroupDetailSerializer(group)
        return Response(serializer.data)

    def patch(self, request, pk):
        try:
            group = Group.objects.get(pk=pk)
        except Group.DoesNotExist:
            return Response({'detail': 'Group not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = GroupDetailSerializer(group, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        try:
            group = Group.objects.get(pk=pk)
        except Group.DoesNotExist:
            return Response({'detail': 'Group not found'}, status=status.HTTP_404_NOT_FOUND)
        group.delete()
        return Response({'message': 'Group deleted'})


class PermissionListView(APIView):
    """List all available permissions or create a custom permission."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        permissions = Permission.objects.select_related('content_type').all().order_by(
            'content_type__app_label', 'content_type__model', 'codename'
        )
        search = request.query_params.get('search')
        if search:
            permissions = permissions.filter(
                models.Q(name__icontains=search) |
                models.Q(codename__icontains=search) |
                models.Q(content_type__app_label__icontains=search) |
                models.Q(content_type__model__icontains=search)
            )
        serializer = PermissionSerializer(permissions, many=True)
        return Response(serializer.data)

    def post(self, request):
        """Create a custom permission."""
        name = request.data.get('name')
        codename = request.data.get('codename')
        content_type_id = request.data.get('content_type')

        if not all([name, codename, content_type_id]):
            return Response(
                {'detail': 'name, codename, and content_type are required.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            ct = ContentType.objects.get(pk=content_type_id)
        except ContentType.DoesNotExist:
            return Response({'detail': 'Invalid content_type.'}, status=status.HTTP_400_BAD_REQUEST)

        if Permission.objects.filter(codename=codename, content_type=ct).exists():
            return Response(
                {'detail': f'Permission with codename "{codename}" already exists for this model.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        perm = Permission.objects.create(name=name, codename=codename, content_type=ct)
        return Response(PermissionSerializer(perm).data, status=status.HTTP_201_CREATED)


class PermissionDetailView(APIView):
    """Get, update, or delete a permission."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request, pk):
        try:
            perm = Permission.objects.select_related('content_type').get(pk=pk)
        except Permission.DoesNotExist:
            return Response({'detail': 'Permission not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response({
            'id': perm.id,
            'name': perm.name,
            'codename': perm.codename,
            'content_type': perm.content_type_id,
            'app_label': perm.content_type.app_label,
            'model': perm.content_type.model,
        })

    def patch(self, request, pk):
        try:
            perm = Permission.objects.get(pk=pk)
        except Permission.DoesNotExist:
            return Response({'detail': 'Permission not found'}, status=status.HTTP_404_NOT_FOUND)

        if 'name' in request.data:
            perm.name = request.data['name']
        if 'codename' in request.data:
            perm.codename = request.data['codename']
        if 'content_type' in request.data:
            try:
                ct = ContentType.objects.get(pk=request.data['content_type'])
                perm.content_type = ct
            except ContentType.DoesNotExist:
                return Response({'detail': 'Invalid content_type.'}, status=status.HTTP_400_BAD_REQUEST)
        perm.save()
        return Response(PermissionSerializer(perm).data)

    def delete(self, request, pk):
        try:
            perm = Permission.objects.get(pk=pk)
        except Permission.DoesNotExist:
            return Response({'detail': 'Permission not found'}, status=status.HTTP_404_NOT_FOUND)

        # Prevent deleting Django's auto-generated permissions (add_, change_, delete_, view_)
        auto_prefixes = ('add_', 'change_', 'delete_', 'view_')
        if perm.codename.startswith(auto_prefixes):
            return Response(
                {'detail': 'Cannot delete auto-generated permissions.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        perm.delete()
        return Response({'message': 'Permission deleted'})


class ContentTypeListView(APIView):
    """List all content types (for the permission create form's model dropdown)."""
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        cts = ContentType.objects.all().order_by('app_label', 'model')
        data = [
            {'id': ct.id, 'app_label': ct.app_label, 'model': ct.model, 'label': f"{ct.app_label} | {ct.model}"}
            for ct in cts
        ]
        return Response(data)
