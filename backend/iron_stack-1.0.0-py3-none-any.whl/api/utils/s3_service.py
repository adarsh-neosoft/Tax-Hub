from io import BytesIO

import boto3
from PIL import Image
from botocore.exceptions import ClientError
from pypdf import PdfReader, PdfWriter

from api.logger import s3_logger


class S3Service:
    """
    A Service class for common Amazon S3 operations such as uploading, downloading,
    and listing files within a specified bucket.
    """

    target_long_sides = {
        1: 2560,  # 2K resolution
        2: 1920,  # Full HD
        3: 1600,
        4: 1280,  # HD Ready
        5: 1024,
        6: 800,
        7: 640,
        8: 480,
        9: 320  # For thumbnails
    }

    def __init__(self, bucket_name: str):
        """
        Initializes the S3Service with a specified S3 bucket name.
        :param bucket_name: The name of the S3 bucket to operate on.
        """
        if not isinstance(bucket_name, str) or not bucket_name:
            raise ValueError("Bucket name must be a non-empty string.")
        self.bucket_name = bucket_name
        self.s3_client = boto3.client('s3')

    def upload(self, file_data, key: str, compress_level: int = 0, resize_level: int = 0):
        """
        Uploads a file to the specified S3 bucket.
        :param file_data: In-memory file object (e.g., InMemoryUploadedFile).
        :param key: The S3 object key (path within the bucket) where the file
                       will be stored. Backslashes in the key will be converted to forward slashes.
        :param compress_level: The level of compression to use. Value will be from 0(no-compression) to 9(highest)
        :param resize_level: The level of resizing to use. Value will be according to target_long_sides
        :return: Path of the uploaded file in S3 bucket
        :raises ClientError: If an AWS S3 client error occurs during the upload (e.g., permissions).
        :raises Exception: For any other unexpected errors during the upload process.
        """
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string representing the S3 object key.")

        s3_key = key.replace("\\", "/")  # Ensure S3 compatible key

        try:
            if not hasattr(file_data, 'read'):
                raise ValueError("In-memory file_data must be a file-like object with a 'read' method.")
            if compress_level > 0:
                file_data = self.compress(file_data, s3_key, compress_level)
            if resize_level > 0:
                file_data = self.resize(file_data, s3_key, resize_level)
            s3_logger.info(f"Successfully uploaded in-memory file to s3://{self.bucket_name}/{s3_key}")
            self.s3_client.upload_fileobj(file_data, self.bucket_name, s3_key)
            return f"s3://{self.bucket_name}/{s3_key}"
        except ClientError as e:
            s3_logger.error(f"S3 ClientError during upload of '{file_data}' to '{s3_key}': {e}")
            raise e
        except Exception as e:
            s3_logger.error(f"An unexpected error occurred during upload: {e}")
            raise e

    def compress(self, file_data, key, compress_level):
        """
        Compresses a PDF/JPG/TIFF/PNG file
        :param file_data: In-memory file object (e.g., InMemoryUploadedFile).
        :param key: The S3 object key (path within the bucket) where the file
                       will be stored. Backslashes in the key will be converted to forward slashes.
        :param compress_level: The level of compression to use. (int 0-9)
        :return: file object
        :raises Exception: For any other unexpected errors during the compression process.
        """

        if file_data.file.content_type == 'application/pdf':
            try:
                s3_logger.info(f"Compressing PDF: {key}")
                reader = PdfReader(file_data)
                writer = PdfWriter()
                for page in reader.pages:
                    writer.add_page(page)
                for page in writer.pages:
                    page.compress_content_streams(level=compress_level)
                writer.add_metadata(reader.metadata)
                output_pdf_stream = BytesIO()
                writer.write(output_pdf_stream)
                output_pdf_stream.seek(0)
                s3_logger.info(f"PDF compression completed: {key}")
                return output_pdf_stream
            except Exception as e:
                s3_logger.error(f"An unexpected error occurred during compression: {e}")
                raise e
        elif file_data.file.content_type == 'image/png':
            try:
                s3_logger.info(f"Compressing PNG: {key}")
                output_buffer = BytesIO()
                with Image.open(file_data) as img:
                    img.save(
                        output_buffer,
                        "PNG",
                        optimize=True,
                        compress_level=compress_level
                    )
                output_buffer.seek(0)
                s3_logger.info(f"PNG compression completed: {key}")
                return output_buffer
            except Exception as e:
                s3_logger.error(f"An unexpected error occurred during compression: {e}")
                raise e
        elif file_data.file.content_type == 'application/jpeg':
            try:
                s3_logger.info(f"Compressing JPG: {key}")
                output_buffer = BytesIO()
                with Image.open(file_data) as img:
                    img.save(output_buffer,
                             "JPEG",
                             quality=compress_level * 10,
                             optimize=True)
                output_buffer.seek(0)
                s3_logger.info(f"JPG compression completed: {key}")
                return output_buffer
            except Exception as e:
                s3_logger.error(f"An unexpected error occurred during compression: {e}")
                raise e
        elif file_data.file.content_type == 'application/tiff':
            try:
                s3_logger.info(f"Compressing TIFF: {key}")
                img = Image.open(file_data)
                num_pages = img.n_frames
                processed_pages_streams = []

                for i in range(num_pages):
                    img.seek(i)
                    current_page_img = img.copy()
                    output_page_stream = io.BytesIO()
                    current_page_img.save(output_page_stream, format="TIFF", compression="tiff_deflate")
                    output_page_stream.seek(0)
                    processed_pages_streams.append(output_page_stream.getvalue())

                if processed_pages_streams:
                    first_page_img = Image.open(io.BytesIO(processed_pages_streams[0]))
                    remaining_pages_for_append = [Image.open(io.BytesIO(s)) for s in processed_pages_streams[1:]]
                    output_multi_page_stream = io.BytesIO()
                    first_page_img.save(
                        output_multi_page_stream,
                        format="TIFF",
                        save_all=True,
                        append_images=remaining_pages_for_append,
                        compression="tiff_deflate",
                        compress_level=compress_level
                    )
                    output_multi_page_stream.seek(0)
                    s3_logger.info(f"TIFF compression completed: {key}")
                    return output_multi_page_stream
                else:
                    s3_logger.info(f"TIFF compression failed: {key}")
                    return file_data

            except Exception as e:
                s3_logger.error(f"An unexpected error occurred during compression: {e}")
                return file_data
        else:
            s3_logger.error(f"Unsupported file type: {file_data.file.content_type}")
            return file_data

    def resize(self, file_data, key, resize_level):
        """
        Resize JPG/PNG file
        :param file_data: In-memory file object (e.g., InMemoryUploadedFile).
        :param key: The S3 object key (path within the bucket) where the file
                       will be stored. Backslashes in the key will be converted to forward slashes.
        :param resize_level: The level of resize to use. (int 0-9)
        :return: file object
        :raises Exception: For any other unexpected errors during the resizing process.
        """
        if file_data.file.content_type in ['image/png', 'image/jpeg']:
            try:
                image_format = 'PNG' if file_data.file.content_type == 'image/png' else 'JPEG'
                with Image.open(file_data) as img:
                    original_width, original_height = img.size
                    s3_logger.info(f"Resizing Image: {key}, original size {original_width}x{original_height}")

                    target_max_long_side = min(
                        self.target_long_sides.get(resize_level, max(original_width, original_height)),
                        max(original_width, original_height))

                    # if the original image is already smaller than the target, no resize is needed.
                    if target_max_long_side >= max(original_width, original_height):
                        new_width, new_height = original_width, original_height
                        s3_logger.info(f"{key} resize level is greater than original size")
                        return file_data
                    else:
                        # Calculate new dimensions while maintaining aspect ratio
                        if original_width > original_height:
                            new_width = target_max_long_side
                            new_height = int(original_height * (target_max_long_side / original_width))
                        else:
                            new_height = target_max_long_side
                            new_width = int(original_width * (target_max_long_side / original_height))

                        new_width = max(1, new_width)
                        new_height = max(1, new_height)

                        s3_logger.info(f"Resizing Image: {key}, new width {new_width}x{new_height}")

                        if (new_width, new_height) != (original_width, original_height):
                            resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                            output_buffer = BytesIO()
                            resized_img.save(output_buffer, format=image_format)
                            s3_logger.info(f"Image resize completed: {key}")
                            output_buffer.seek(0)
                            return output_buffer
                        else:
                            s3_logger.info(f"{key} resize level is same as original size")
                            return file_data
            except Exception as e:
                s3_logger.error(f"An unexpected error occurred during resizing: {e}")
                raise e
        else:
            s3_logger.info(f"{key} is not an image file")
            return file_data

    def download(self, key: str) -> bytes:
        """
        Downloads a file from the S3 bucket and returns its content as bytes.
        :param key: The S3 object key (path within the bucket) of the file to download.
        :return: The content of the downloaded file as a byte string.
        :raises ClientError: If an AWS S3 client error occurs during the download (e.g., object not found, permissions).
        :raises Exception: For any unexpected errors during the download.
        """
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a non-empty string representing the S3 object key.")

        in_memory_file = BytesIO()
        try:
            self.s3_client.download_fileobj(self.bucket_name, key, in_memory_file)
            file_content = in_memory_file.getvalue()
            s3_logger.info(f"Successfully downloaded s3://{self.bucket_name}/{key}")
            return file_content
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == 'NoSuchKey':
                s3_logger.error(f"S3 object not found: s3://{self.bucket_name}/{key}")
                raise FileNotFoundError(f"The S3 object '{key}' was not found in bucket '{self.bucket_name}'.")
            else:
                s3_logger.error(f"S3 ClientError during download of '{key}': {e}")
                raise
        except Exception as e:
            s3_logger.error(f"An unexpected error occurred during download: {e}")
            raise

    def list_files(self, folder_prefix: str = '') -> list[str]:
        """
        List all files in the S3 bucket.
        :param folder_prefix: The prefix (folder path) to list objects from.
                                 If provided, it should typically end with a '/' to
                                 filter by directory. An empty string will list all
                                 objects in the bucket's root.
        :return: A list of file keys (object keys) found in the specified folder.
                       Returns an empty list if no files are found or the folder doesn't exist.
        :raises ClientError: If an AWS S3 client error occurs during listing (e.g., permissions).
        :raises Exception: For any other unexpected errors during the listing process.
        """
        if not isinstance(folder_prefix, str):
            raise ValueError("folder_prefix must be a string.")

        files = []
        paginator = self.s3_client.get_paginator('list_objects_v2')

        # Ensure the folder_prefix ends with a '/' to treat it as a directory,
        # unless it's an empty string for the bucket root.
        if folder_prefix and not folder_prefix.endswith('/'):
            folder_prefix += '/'
            s3_logger.warning(
                f"Folder prefix '{folder_prefix[:-1]}' adjusted to '{folder_prefix}' for directory listing.")

        try:
            pages = paginator.paginate(Bucket=self.bucket_name, Prefix=folder_prefix)

            for page in pages:
                if "Contents" in page:
                    for obj in page['Contents']:
                        # Exclude the folder prefix itself if it's listed as an object
                        # (e.g., a zero-byte object representing the folder).
                        if obj['Key'] != folder_prefix:
                            files.append(obj['Key'])
            s3_logger.info(f"Successfully listed {len(files)} files in s3://{self.bucket_name}/{folder_prefix}")
            return files
        except ClientError as e:
            s3_logger.error(f"S3 ClientError during listing files in '{folder_prefix}': {e}")
            raise
        except Exception as e:
            s3_logger.error(f"An unexpected error occurred during file listing: {e}")
            raise
