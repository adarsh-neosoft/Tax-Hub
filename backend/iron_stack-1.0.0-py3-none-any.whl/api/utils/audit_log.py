import json

from django.contrib.admin.models import LogEntry, CHANGE, ADDITION
from django.contrib.contenttypes.models import ContentType

from api.helpers import dict_diff
from api.utils.encryption_utils import decrypt
from project import settings


def create_audit_log(action_user, obj, new_data):
    """
    Creates Audit Log for the given object
    :param action_user: User who is performing the action
    :param obj: Model Object
    :param new_data: New Data for the object
    :return: None
    """
    current_data = {}
    for key, value in new_data.items():
        if key in obj.model_config['exclude_from_audit_log']:
            continue
        current_data[key] = getattr(obj, key)
        if key in obj.model_config['encrypted_fields']:
            current_data[key] = decrypt(current_data[key], settings.SECRET_KEY)

    changes = dict_diff(current_data, new_data)
    log = {
        'user_id': action_user.pk,
        'content_type_id': ContentType.objects.get_for_model(obj).pk,
        'object_id': obj.pk,
        'object_repr': str(obj),
        'change_message': json.dumps(changes),
        'action_flag': ADDITION if obj is None else CHANGE
    }

    LogEntry.objects.log_action(**log)
