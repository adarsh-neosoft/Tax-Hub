import hashlib
import logging
import os
from base64 import b64encode, b64decode

from Crypto.Cipher import AES
from django.conf import settings

logger = logging.getLogger(__name__)


# AES-GCM key derived deterministically from SECRET_KEY + a fixed derivation
# salt. Using a fixed salt here is fine: the salt's job for scrypt is to
# harden the KDF against rainbow tables, not to hide the key. A per-process
# random salt (the previous behavior) meant encrypted rows could not survive
# a process restart. Override the derivation salt explicitly with
# ENCRYPTION_DERIVATION_SALT when rotating keys.
_DEFAULT_DERIVATION_SALT = b"api.utils.encryption_utils.v1"


def _derive_key():
    salt = os.environ.get("ENCRYPTION_DERIVATION_SALT")
    salt_bytes = salt.encode("utf-8") if salt else _DEFAULT_DERIVATION_SALT
    return hashlib.scrypt(
        settings.SECRET_KEY.encode("utf-8"),
        salt=salt_bytes,
        n=2 ** 14,
        r=8,
        p=1,
        dklen=32,
    )


_KEY = _derive_key()


def encrypt(message, password=None):
    """
    Encrypt `message` with AES-GCM using a key derived from SECRET_KEY.

    Produces a `<cipher>*<nonce>*<tag>` string. The historical format included
    a per-call salt field; we keep the 4-part `cipher*salt*nonce*tag` wire
    shape for backwards compatibility but the `salt` slot is now unused.

    :param message: String to encrypt.
    :param password: Retained for backwards compatibility; ignored.
    """
    if message is None:
        return None
    if not isinstance(message, str):
        message = str(message)

    cipher = AES.new(_KEY, AES.MODE_GCM)
    cipher_text, tag = cipher.encrypt_and_digest(message.encode("utf-8"))

    return "*".join([
        b64encode(cipher_text).decode("utf-8"),
        "",  # legacy salt slot, unused
        b64encode(cipher.nonce).decode("utf-8"),
        b64encode(tag).decode("utf-8"),
    ])


def decrypt(encrypted_string, password=None):
    """
    Decrypt a value produced by `encrypt`.

    Values that don't look like an encrypted payload (wrong shape, wrong key,
    tampered) are returned unchanged. This lets legacy plaintext rows continue
    to round-trip while encrypted rows decode correctly.

    :param encrypted_string: Encrypted string.
    :param password: Retained for backwards compatibility; ignored.
    """
    if not encrypted_string or not isinstance(encrypted_string, str):
        return encrypted_string

    parts = encrypted_string.split("*")
    if len(parts) != 4:
        return encrypted_string

    try:
        cipher_text = b64decode(parts[0])
        nonce = b64decode(parts[2])
        tag = b64decode(parts[3])
        cipher = AES.new(_KEY, AES.MODE_GCM, nonce=nonce)
        return cipher.decrypt_and_verify(cipher_text, tag).decode("utf-8")
    except (ValueError, KeyError) as e:
        logger.debug("decrypt: payload could not be decoded (%s); returning as-is.", e)
        return encrypted_string
