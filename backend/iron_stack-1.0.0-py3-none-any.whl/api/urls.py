from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from api import views
from api import notification_views
from api.views import TokenObtainPairCustomView, LogoutView
from api.rbac_views import (
    UserListView, UserDetailView,
    GroupListView, GroupDetailView,
    PermissionListView, PermissionDetailView,
    ContentTypeListView,
)

urlpatterns = [
    path("token/", TokenObtainPairCustomView.as_view(), name="token_obtain_pair"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("logout/", LogoutView.as_view(), name="logout"),

    # RBAC endpoints
    path("rbac/users/", UserListView.as_view(), name="rbac_user_list"),
    path("rbac/users/<int:pk>/", UserDetailView.as_view(), name="rbac_user_detail"),
    path("rbac/groups/", GroupListView.as_view(), name="rbac_group_list"),
    path("rbac/groups/<int:pk>/", GroupDetailView.as_view(), name="rbac_group_detail"),
    path("rbac/permissions/", PermissionListView.as_view(), name="rbac_permission_list"),
    path("rbac/permissions/<int:pk>/", PermissionDetailView.as_view(), name="rbac_permission_detail"),
    path("rbac/content-types/", ContentTypeListView.as_view(), name="rbac_content_type_list"),

    # Audit log
    path("audit/<str:app_label>/<str:model_name>/<int:object_id>/", views.AuditLogView.as_view(), name="audit_log"),

    # Push notifications
    path("notifications/", notification_views.NotificationListView.as_view(), name="notification_list"),
    path("notifications/poll/", notification_views.NotificationPollView.as_view(), name="notification_poll"),

    # Generic model endpoints
    path("<str:app_label>/<str:model_name>/dropdown", views.GenericDropdownAPIView.as_view()),
    path("<str:app_label>/<str:model_name>/<str:pk>/", views.GenericObjectAPIView.as_view()),
    path("<str:app_label>/<str:model_name>/", views.GenericListAPIView.as_view()),
    path("", views.DefaultView.as_view())
]
