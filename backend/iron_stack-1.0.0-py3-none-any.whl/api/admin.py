import json, urllib.parse
from django.contrib import admin
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import User, Permission, Group
from django.contrib.auth.admin import UserAdmin

class CustomUserAdmin(UserAdmin):
    def save_model(self, request, obj, form, change):
        """
        Overrides the save behavior for the built-in User model.

        This method is called when an admin user clicks 'Save' on the
        user change form to store extra audit logs.
        """

        if 'groups' in form.changed_data or 'user_permissions' in form.changed_data:
            changes = {'permissions': {}, 'groups': {}}

            # Converting the request body from bytes to json
            data_string = request.body.decode('utf-8')
            data_dict_lists = urllib.parse.parse_qs(data_string, keep_blank_values=True)
            data_dict = {
                key: value for key, value in data_dict_lists.items()
            }

            # Evaluating the changes in permissions
            new_permissions = set(Permission.objects.filter(pk__in=data_dict['user_permissions']).values_list('codename', flat=True)) if 'user_permissions' in data_dict else set()
            old_permissions = set(Permission.objects.filter(user=obj).values_list('codename', flat=True))
            permissions_added = new_permissions.difference(old_permissions)
            permissions_removed = old_permissions.difference(new_permissions)
            # Updating the changes dict
            changes['permissions']['added'] = list(permissions_added) if permissions_added else []
            changes['permissions']['removed'] = list(permissions_removed) if permissions_removed else []

            # Evaluating the changes in groups
            new_groups = set(Group.objects.filter(pk__in=data_dict['groups']).values_list('name', flat=True)) if 'groups' in data_dict else set()
            old_groups = set(obj.groups.all().values_list('name',flat=True))
            groups_added = new_groups.difference(old_groups)
            groups_removed = old_groups.difference(new_groups)
            # Updating the changes dict
            changes['groups']['added'] = list(groups_added) if groups_added else []
            changes['groups']['removed'] = list(groups_removed) if groups_removed else []

            # Add custom admin log entry
            LogEntry.objects.log_action(
                user_id=request.user.pk,
                content_type_id= ContentType.objects.get_for_model(obj).pk,
                object_id=obj.pk,
                object_repr=str(obj),
                action_flag=CHANGE,
                change_message=json.dumps(changes))
        super().save_model(request, obj, form, change)

try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass
admin.site.register(User, CustomUserAdmin)