import datetime
import os

from django.conf import settings
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Q
from django.db.models.functions import Lower
from django.utils import timezone
from ldap3 import Server, Connection, SUBTREE, ALL_ATTRIBUTES

from api.utils.logging import init_logging

# Expect LDAP_CONFIG on FRAMEWORK_SETTINGS, matching the shape used by
# `ldap_data` management command. Keys: HOST, USER_DN, PASSWORD, ATTRIBUTES.
LDAP_CONFIG = settings.FRAMEWORK_SETTINGS.get('LDAP_CONFIG', {})

deactivate_user_logs = init_logging(
    log_name='deactivate_user_logs',
    log_level='DEBUG',
    rotation_criteria='time',
    rotate_interval=1,
    rotate_when='d',
    backup_count=30,
    log_directory=os.path.join(settings.BASE_DIR, "logs"),
)


class Command(BaseCommand):
    help = "Deactivate Django users who are no longer present in LDAP or who have been idle for too long."

    def handle(self, *args, **options):
        if not LDAP_CONFIG:
            raise CommandError(
                "FRAMEWORK_SETTINGS['LDAP_CONFIG'] is not configured. "
                "Expected keys: HOST, USER_DN, PASSWORD, ATTRIBUTES."
            )

        groups_in = []
        groups_not_in = ['vendor']
        last_login_valid_for = 180  # Deactivate users whose last_login is more than x days

        deactivate_user_logs.info("User Deactivation command initiated.")
        try:
            server = Server(LDAP_CONFIG['HOST'], use_ssl=False, get_info=ALL_ATTRIBUTES)
            deactivate_user_logs.info(f"Attempting to connect to LDAP server: {LDAP_CONFIG['HOST']}")
        except Exception as e:
            deactivate_user_logs.error(f"Failed to initialize LDAP server object: {e}")
            raise CommandError(f"Could not initialize LDAP server: {e}")

        conn = Connection(server, user=LDAP_CONFIG['USER_DN'], password=LDAP_CONFIG['PASSWORD'], auto_bind=True)
        if not conn.bound:
            deactivate_user_logs.error(f"Failed to bind to LDAP server with user DN: {LDAP_CONFIG['USER_DN']}")
            raise CommandError("Failed to bind to LDAP server. Check credentials.")
        deactivate_user_logs.info("Successfully bound to LDAP server.")

        all_ldap_entries_data = []
        cookie = None
        while True:
            conn.search(
                search_base='dc=MyAMNS,dc=in',
                search_filter="(&(sAMAccountName=*)(objectClass=User)(!(userAccountControl=514)))",
                search_scope=SUBTREE,
                attributes=LDAP_CONFIG['ATTRIBUTES'],
                size_limit=0,
                paged_size=5000,
                paged_cookie=cookie,
            )
            users_page = conn.entries
            all_ldap_entries_data.extend(users_page)
            deactivate_user_logs.info(f"Found {len(users_page)} LDAP entries.")

            cookie = conn.result['controls']['1.2.840.113556.1.4.319']['value']['cookie']
            if not cookie:
                deactivate_user_logs.info("No more LDAP pages.")
                break

        deactivate_user_logs.info(f'LDAP fetch completed, total record: {len(all_ldap_entries_data)}')
        ldap_records = []
        deactivate_user_logs.info('Processing LDAP data')
        for entry in all_ldap_entries_data:
            entry_data = {}
            for attr in LDAP_CONFIG['ATTRIBUTES']:
                if attr in entry and entry[attr].value is not None:
                    if attr == 'objectGUID':
                        entry_data[attr] = str(entry[attr].value)
                    elif isinstance(entry[attr].value, list):
                        entry_data[attr] = "; ".join([str(v) for v in entry[attr].value])
                    else:
                        entry_data[attr] = str(entry[attr].value)
                else:
                    entry_data[attr] = ''
            ldap_records.append(entry_data)

        deactivate_user_logs.info('Processing LDAP data completed')

        active_users = [each['sAMAccountName'] for each in ldap_records]

        internal_users = User.objects.filter(is_active=True)
        if groups_in:
            internal_users = internal_users.filter(groups__name__in=groups_in)
        if groups_not_in:
            internal_users = internal_users.exclude(groups__name__in=groups_not_in)

        deactivate_user_logs.info(f'Internal Users Found : {internal_users.count()}')

        to_deactivate_users = internal_users.annotate(
            lower_username=Lower('username')
        ).exclude(lower_username__in=[u.lower() for u in active_users])

        for each in to_deactivate_users:
            each.is_active = False
            each.save()
            deactivate_user_logs.info(f'User {each.username} deactivated (not in LDAP)')
            LogEntry.objects.log_action(
                user_id=each.pk,
                content_type_id=ContentType.objects.get_for_model(each).pk,
                object_id=each.pk,
                object_repr=str(each),
                action_flag=CHANGE,
                change_message='User deactivated automatically as found inactive in LDAP',
            )

        date_filter = timezone.now() - datetime.timedelta(days=last_login_valid_for)
        inactive_users = internal_users.filter(
            Q(is_active=True),
            Q(last_login__isnull=True) | Q(last_login__lt=date_filter),
        )

        for each in inactive_users:
            each.is_active = False
            each.save()
            deactivate_user_logs.info(f'User {each.username} deactivated (idle > {last_login_valid_for} days)')
            LogEntry.objects.log_action(
                user_id=each.pk,
                content_type_id=ContentType.objects.get_for_model(each).pk,
                object_id=each.pk,
                object_repr=str(each),
                action_flag=CHANGE,
                change_message=f'User deactivated automatically as found inactive for last {last_login_valid_for} days',
            )
