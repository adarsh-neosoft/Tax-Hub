import os

import pandas as pd
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from ldap3 import Server, Connection, SUBTREE, ALL_ATTRIBUTES

from api.utils.logging import init_logging

LDAP_SYNC_LOGS = init_logging(
    log_name='LDAP_SYNC_LOGS',
    log_directory=os.path.join(settings.BASE_DIR, 'logs'),
)

# LDAP connection details live in settings.FRAMEWORK_SETTINGS['LDAP_CONFIG']
# and are sourced from environment variables. Expected keys: HOST, USER_DN,
# PASSWORD, ATTRIBUTES.
LDAP_CONFIG = settings.FRAMEWORK_SETTINGS.get('LDAP_CONFIG', {})


class Command(BaseCommand):
    help = "Sync users from LDAP and write them to ldap_records.csv."

    def handle(self, *args, **options):
        LDAP_SYNC_LOGS.info("LDAP sync command initiated.")

        if not LDAP_CONFIG or not LDAP_CONFIG.get('HOST'):
            raise CommandError(
                "FRAMEWORK_SETTINGS['LDAP_CONFIG'] is not configured. "
                "Set LDAP_HOST, LDAP_USER_DN, LDAP_PASSWORD environment variables."
            )

        try:
            server = Server(LDAP_CONFIG['HOST'], use_ssl=False, get_info=ALL_ATTRIBUTES)
            LDAP_SYNC_LOGS.info(f"Attempting to connect to LDAP server: {LDAP_CONFIG['HOST']}")
        except Exception as e:
            LDAP_SYNC_LOGS.error(f"Failed to initialize LDAP server object: {e}")
            raise CommandError(f"Could not initialize LDAP server: {e}")

        conn = Connection(
            server,
            user=LDAP_CONFIG['USER_DN'],
            password=LDAP_CONFIG['PASSWORD'],
            auto_bind=True,
        )
        if not conn.bound:
            LDAP_SYNC_LOGS.error(f"Failed to bind to LDAP server with user DN: {LDAP_CONFIG['USER_DN']}")
            raise CommandError("Failed to bind to LDAP server. Check credentials.")
        LDAP_SYNC_LOGS.info("Successfully bound to LDAP server.")

        all_ldap_entries_data = []
        cookie = None
        while True:
            conn.search(
                search_base='dc=MyAMNS,dc=in',
                search_filter="(&(sAMAccountName=*)(objectClass=User)(!(userAccountControl=514)))",
                search_scope=SUBTREE,
                attributes=LDAP_CONFIG['ATTRIBUTES'],
                size_limit=0,
                paged_size=5000,
                paged_cookie=cookie,
            )
            users_page = conn.entries
            all_ldap_entries_data.extend(users_page)
            LDAP_SYNC_LOGS.info(f"Found {len(users_page)} LDAP entries.")

            cookie = conn.result['controls']['1.2.840.113556.1.4.319']['value']['cookie']
            if not cookie:
                LDAP_SYNC_LOGS.info("No more LDAP pages.")
                break

        LDAP_SYNC_LOGS.info(f'LDAP fetch completed, total record: {len(all_ldap_entries_data)}')

        ldap_records = []
        LDAP_SYNC_LOGS.info('Processing LDAP data')
        for entry in all_ldap_entries_data:
            entry_data = {}
            for attr in LDAP_CONFIG['ATTRIBUTES']:
                if attr in entry and entry[attr].value is not None:
                    if attr == 'objectGUID':
                        entry_data[attr] = str(entry[attr].value)
                    elif isinstance(entry[attr].value, list):
                        entry_data[attr] = "; ".join([str(v) for v in entry[attr].value])
                    else:
                        entry_data[attr] = str(entry[attr].value)
                else:
                    entry_data[attr] = ''
            ldap_records.append(entry_data)
        LDAP_SYNC_LOGS.info('Processing LDAP data completed')

        ldap_records_updated = []
        for each in ldap_records:
            manager_raw = each.get('manager', '') or ''
            manager_parts = manager_raw.split(',')
            manager = manager_parts[1].strip() if len(manager_parts) > 1 else ''

            ldap_records_updated.append({
                'amns_user_id': each['sAMAccountName'],
                'first_name': each['givenName'],
                'last_name': each['sn'],
                'full_name': f"{each['givenName']} {each['sn']}",
                'display_name': each['displayName'],
                'sap_code': each['physicalDeliveryOfficeName'],
                'email_id': each['mail'],
                'designation': each['title'],
                'department': each['department'],
                'manager': manager,
                'company': each['company'],
                'telephone_number': each['telephoneNumber'],
                'mobile_no': each['mobile'],
                'address': each['streetAddress'],
                'city': each['l'],
                'state': each['st'],
                'postalcode': each['postalCode'],
                'country': each['co'],
                'object_GUID': each['objectGUID'],
            })

        output_path = os.path.join(settings.BASE_DIR, 'ldap_records.csv')
        pd.DataFrame(ldap_records_updated).to_csv(output_path, index=False)
        LDAP_SYNC_LOGS.info(f"Wrote {len(ldap_records_updated)} records to {output_path}")
