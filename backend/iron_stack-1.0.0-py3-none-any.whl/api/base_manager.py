from django.db import models

class BaseManager(models.Manager):

    def filter_by_created_by(self, user):
        return self.filter(created_by=user)

    def filter_by_last_updated_by(self, user):
        return self.filter(last_updated_by=user)

    def filter_by_is_active(self, is_active):
        return self.filter(is_active=is_active)

    def filter_by_is_deleted(self, is_deleted):
        return self.filter(is_deleted=is_deleted)

    def filter_by_is_approved(self, is_approved):
        return self.filter(is_approved=is_approved)

