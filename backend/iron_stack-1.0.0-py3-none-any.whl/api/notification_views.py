"""
Push notification API views.
"""
from django.contrib.auth.models import User, Group
from django.db.models import Q
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from api.notification_models import PushNotification


class NotificationListView(APIView):
    """List notifications for the current user, or create a new one (admin)."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Get notifications for the current user (last 50)."""
        user = request.user
        notifications = PushNotification.objects.filter(
            Q(target_users=user) |
            Q(target_groups__in=user.groups.all()) |
            Q(send_to_all=True)
        ).distinct().order_by('-created_at')[:50]

        # Track which ones are "new" (after last poll)
        last_seen = request.query_params.get('after')

        data = []
        for n in notifications:
            data.append({
                'id': n.id,
                'title': n.title,
                'message': n.message,
                'url': n.url,
                'priority': n.priority,
                'created_by': n.created_by.get_full_name() or n.created_by.username,
                'created_at': n.created_at.isoformat(),
            })
        return Response(data)

    def post(self, request):
        """Create a new push notification (admin only)."""
        if not request.user.is_staff:
            return Response({'detail': 'Admin only'}, status=403)

        title = request.data.get('title')
        message = request.data.get('message', '')
        url = request.data.get('url', '')
        priority = request.data.get('priority', 'normal')
        target_user_ids = request.data.get('target_users', [])
        target_group_ids = request.data.get('target_groups', [])
        send_to_all = request.data.get('send_to_all', False)

        if not title:
            return Response({'detail': 'title is required'}, status=400)

        notification = PushNotification.objects.create(
            title=title,
            message=message,
            url=url,
            priority=priority,
            send_to_all=send_to_all,
            created_by=request.user,
        )

        if target_user_ids:
            notification.target_users.set(User.objects.filter(pk__in=target_user_ids))
        if target_group_ids:
            notification.target_groups.set(Group.objects.filter(pk__in=target_group_ids))

        return Response({
            'id': notification.id,
            'title': notification.title,
            'message': notification.message,
        }, status=201)


class NotificationPollView(APIView):
    """
    Poll for new notifications since a given timestamp.
    Returns only notifications created AFTER the 'since' parameter.
    Used by the frontend to trigger desktop notifications for new items.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        since = request.query_params.get('since')

        qs = PushNotification.objects.filter(
            Q(target_users=user) |
            Q(target_groups__in=user.groups.all()) |
            Q(send_to_all=True)
        ).distinct().order_by('-created_at')

        if since:
            from datetime import datetime
            try:
                since_dt = datetime.fromisoformat(since.replace('Z', '+00:00'))
                qs = qs.filter(created_at__gt=since_dt)
            except (ValueError, TypeError):
                pass

        notifications = qs[:10]
        data = [{
            'id': n.id,
            'title': n.title,
            'message': n.message,
            'url': n.url,
            'priority': n.priority,
            'created_at': n.created_at.isoformat(),
        } for n in notifications]

        return Response(data)
