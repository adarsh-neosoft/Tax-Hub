# Intentionally empty.
#
# The `api` app ships framework-level code (base model, generic views,
# helpers) but no concrete models. Domain models belong in the
# project-level apps listed in settings.PROJECT_APPS (e.g. `masters`).
