"""
Push notification system models.

Notifications are created targeting specific users or groups.
The frontend polls for unread notifications and triggers desktop alerts.
"""
from django.contrib.auth.models import User, Group
from django.db import models


class PushNotification(models.Model):
    """A notification record that can target users or groups."""

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('normal', 'Normal'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    title = models.CharField(max_length=255)
    message = models.TextField()
    url = models.CharField(max_length=500, blank=True, help_text="Optional URL to navigate to when clicked")
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='normal')

    # Targeting: either specific users, groups, or all
    target_users = models.ManyToManyField(User, blank=True, related_name='push_notifications')
    target_groups = models.ManyToManyField(Group, blank=True, related_name='push_notifications')
    send_to_all = models.BooleanField(default=False)

    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_notifications')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'push_notification'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} ({self.created_at.strftime('%Y-%m-%d %H:%M')})"

    def get_target_users(self):
        """Resolve all target users (direct + group members)."""
        users = set(self.target_users.all())
        for group in self.target_groups.all():
            users.update(group.user_set.all())
        if self.send_to_all:
            users = set(User.objects.filter(is_active=True))
        return users
